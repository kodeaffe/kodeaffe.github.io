/***************************************************************************
 *   Copyright (C) 2005 by Bernat Ràfales                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

//$Revision: 1.13 $

#include "pspcontroller.h"
#include <qdir.h>
#include <qprocess.h>
#include <qstringlist.h>

const short pspversionsupported = 150;


PSPController::PSPController(mainWindow *mainwindow)
{
    //We create the GUI, the PBPManager and the PBPOptions
    this->mainwindow = mainwindow;
    options = new PSPOptions();
    pbpmanager = new PBPManager(options);
    savegamemanager = new savegameManager(options);

    //Temp directory creation. Hardcoded, may be an option
    //in further versions
    options->setTempDir(QDir::homeDirPath() + "/.qpspmanager/.tmp/");
    options->setSavegameDir(QDir::homeDirPath() + "/.qpspmanager/savedata/");
    QDir dir;
    if (!dir.exists(QDir::homeDirPath() + "/.qpspmanager/"))
    {
        dir.mkdir(QDir::homeDirPath() + "/.qpspmanager/");
    }
    if (!dir.exists(options->getTempDir()))
    {
        dir.mkdir(options->getTempDir());
        dir.mkdir(options->getSavegameDir());
    }
    else
    {
        if (!dir.exists(options->getSavegameDir()))
        {
            dir.mkdir(options->getSavegameDir());
        }
    }
    //Check the options stored in the platform independant "directory"
    //We notice the user if one of the necessary ones is not set
    bool rightOptions;
    bool ok = TRUE;
    mainwindow->clearLists();
    rightOptions = checkPSPDir();
    mainwindow->setPSPDirOK(rightOptions);
    setOutputPSPDir();
    ok = ok && rightOptions;

    if(!ok)
    {
        mainwindow->tellError(mainWindow::tr("Some options are not correctly set"));
    }

    /*
    findPSPVersion(options);
    if (pspversion > pspversionsupported)
    {
        mainwindow->disablePBP();
    }

    mainwindow->setPSPDir(options->getPSPDir());
    */

    //TODO: program breaks if we ask the GUI to update
    //the checkBox button of hideDamage option to FALSE value
    //so now I use two excluding radio buttons
    mainwindow->setHideDamage(options->getHideDamage());
    mainwindow->setOverwrite(options->getOverwriteSavegames());
    mainwindow->setLabelInfo(mainWindow::tr("You must open a PBP file before transfering files")); 
}


PSPController::~PSPController()
{
}

void PSPController::openPBPFile(QString filename)
{
    //We read the PBP File submitted by the user and, if 
    //the unpack process exits normally, we notice the
    //GUI of the files which are going to be used.
    int result = pbpmanager->unpack(filename, options->getTempDir());
    if (result > 0)
    {
        options->setFileName(filename);
        options->setIconFile(options->getTempDir() + "ICON0.PNG");
        options->setBackgroundFile(options->getTempDir() + "PIC1.PNG");
        options->setPMFFile(options->getTempDir() + "ICON1.PMF");
        options->setAT3File(options->getTempDir() + "SND0.AT3");
        mainwindow->setIconPix(options->getIconFile());
        mainwindow->setIconFileName(options->getIconFile());
        mainwindow->setBackgroundPix(options->getBackgroundFile());
        mainwindow->setBackgroundFileName(options->getBackgroundFile());
        mainwindow->setPMFFileName(options->getPMFFile());
        mainwindow->setAT3FileName(options->getAT3File());
        mainwindow->setFileName(options->getFileName());

        options->setProgramName(pbpmanager->validDirectory(pbpmanager->programName(filename)));
        setProgramName(options->getProgramName());
    }
    else
    {
        mainwindow->tellError(pbpmanager->getMessage(result));
    }
}


//Those functions ask the options object to check
//if the options submitted are ok and notice the
//GUI about the result

bool PSPController::checkPSPDir()
{
    bool ok;
    ok = options->checkPSPDir();
    mainwindow->setPSPDirOK(ok);
    if (!ok)
    {
        mainwindow->setTransferEnabled(FALSE);
        //mainwindow->hideDamageEnable(FALSE);
        mainwindow->setLabelInfo(mainWindow::tr("You must set the PSP directory before transfering files"));
        mainwindow->disableSavegames();
    }
    else
    {
        //We create the game dir if it does not exist
        QDir gameDir(options->getPSPDir() + "psp/game");
        if (!gameDir.exists())
        {
            gameDir.mkdir(gameDir.absPath());
        }
        if (pbpmanager->checkProgramName(options->getProgramName()))
        {
            mainwindow->setLabelInfo(mainWindow::tr("Files will be transferred to ") + options->getOutputDir() + options->getProgramName());
        }
        else
        {
            mainwindow->setLabelInfo(mainWindow::tr("You must open a PBP file before transfering files"));
        }

        setSavegames();
        mainwindow->hideDamageEnable(TRUE);
    }
    return ok;
}


//Those functions are used to set the options
//in the options object and tell the GUI to
//update itself to reflect the new options
//used

void PSPController::setHideDamage(bool ok)
{
    options->setHideDamage(ok);
}


void PSPController::openPSPDir(QString dir)
{
    options->setPSPDir(dir);
    mainwindow->setPSPDir(options->getPSPDir());
    if (checkPSPDir())
    {
        setOutputPSPDir();
        mainwindow->enableSavegames();
        setSavegames();
    }
}


void PSPController::setProgramName(QString name)
{
    //TODO: check all other parameters (are any? maybe in the future)
    if (pbpmanager->checkProgramName(name))
    {
        options->setProgramName(pbpmanager->validDirectory(name));
        mainwindow->setTextProgramName(options->getProgramName());
        if(!options->checkPSPDir())
        {
            mainwindow->setLabelInfo(mainWindow::tr("You must set the PSP directory before transfering files"));
        }
        else if((options->getFileName()).isEmpty())
        {
            mainwindow->setLabelInfo(mainWindow::tr("You must open a PBP file before transfering files"));
        }
        else
        {
            mainwindow->setLabelInfo(mainWindow::tr("Files will be transferred to ") + options->getOutputDir() + options->getProgramName());
            mainwindow->setTransferEnabled(TRUE);
        }
    }
    else
    {
        mainwindow->setLabelInfo(mainWindow::tr("You must set the PSP directory before transfering files"));
        mainwindow->tellError(mainWindow::tr("The program name is not valid"));
        mainwindow->setTransferEnabled(FALSE);
    }
}


void PSPController::openIcon(QString filename)
{
    //TODO: check that file selected is a valid PNG file
    //to use as an icon for the PSP
    options->setIconFile(filename);
    mainwindow->setIconPix(filename);
    mainwindow->setIconFileName(options->getIconFile());

}


void PSPController::openBackground(QString filename)
{
    if (pbpmanager->checkBackground(filename))
    {
        options->setBackgroundFile(filename);
        mainwindow->setBackgroundPix(filename);
        mainwindow->setBackgroundFileName(options->getBackgroundFile());
    }
    else
    {
        mainwindow->tellError(mainWindow::tr("Invalid background image. Check is 480x272 in size"));
    }
}


void PSPController::setOutputPSPDir()
{
    //TODO: check case of the directory names, don't know
    //if the PSP device is also mounted in linux in a way
    //the directories are all transformed lowercase
    options->setOutputDir(options->getPSPDir() + "psp/game/");
    if(!options->checkPSPDir())
    {
        mainwindow->setLabelInfo(mainWindow::tr("You must set the PSP directory before transfering files"));
    }
    else if((options->getFileName()).isEmpty())
    {
        mainwindow->setLabelInfo(mainWindow::tr("You must open a PBP file before transfering files"));
    }
    else
    {
        mainwindow->setLabelInfo(mainWindow::tr("Files will be transferred to ") + options->getOutputDir() + options->getProgramName());
        mainwindow->setTransferEnabled(TRUE);
    }
}


//Save prefereces, self-explanatory
void PSPController::savePreferences()
{
    options->savePreferences();
}





void PSPController::iconEnabled(bool enabled)
{
    options->setWantIcon(enabled);
}


void PSPController::backgroundEnabled(bool enabled)
{
    options->setWantBackground(enabled);
}


void PSPController::PMFEnabled(bool enabled)
{
    options->setWantMovie(enabled);
}


void PSPController::AT3Enabled(bool enabled)
{
    options->setWantSound(enabled);
}


void PSPController::openPMF(QString filename)
{
    if(pbpmanager->checkPMF(filename))
    {
        options->setPMFFile(filename);
        mainwindow->setPMFFileName(options->getPMFFile());
    }
    else
    {
        mainwindow->tellError(mainWindow::tr("Invalid PMF file"));
    }
}


void PSPController::openAT3(QString filename)
{
    if(pbpmanager->checkAT3(filename))
    {
        options->setAT3File(filename);
        mainwindow->setAT3FileName(options->getAT3File());
    }
    else
    {
        mainwindow->tellError(mainWindow::tr("Invalid AT3 file"));
    }
}


void PSPController::transferFiles()
{
    mainwindow->setTransferringFiles(TRUE);
    int result = pbpmanager->transferFiles();
    mainwindow->setTransferringFiles(FALSE);
    if (result >= 0)
    {
        mainwindow->tellMessage(pbpmanager->getMessage(result));
    }
    else
    {
        mainwindow->tellError(pbpmanager->getMessage(result));
    }
}


bool PSPController::askOverwriteFiles()
{
    return mainwindow->askYesNo(QObject::tr("Destination files already exists. Do you want to overwrite them?"));
}


//Asks the savegame manager to analyze the savegames
//in the computer dir and in the PSP dir and then ask the
//GUI to update its contents
void PSPController::setSavegames()
{
    mainwindow->setComputerSavegames(savegamemanager->getComputerSavegames());
    mainwindow->setPSPSavegames(savegamemanager->getPSPSavegames());
}


/* Get/Find the version of the PSP connected to the machine */
void PSPController::findPSPVersion(PSPOptions *options)
{
    pspversion = pspversionsupported;
    if (QFile::exists(options->getPSPDir() + "psp/system/browser"))
    {
        pspversion = 200;
    }
}



void PSPController::transferSavegamesComputer(QStringList list)
{
    for ( QStringList::Iterator it =list.begin(); it != list.end(); ++it ) 
    {
        //Ask the user if he wants to restore the files
        if (options->getOverwriteSavegames() && savegamemanager->existsComputer(*it))
        {
            if(mainwindow->askYesNo(savegamemanager->getComputerOverwriteMessage(*it)))
            {
                mainwindow->setTransferringFiles(TRUE);
                int result =savegamemanager->transferSavegameComputer(*it);
                mainwindow->setTransferringFiles(FALSE);
                if (result < 0)
                {
                    mainwindow->tellError(savegamemanager->getMessageErrorTransferring());
                }
            }
        }
        else
        {
            mainwindow->setTransferringFiles(TRUE);
            int result =savegamemanager->transferSavegameComputer(*it);
            mainwindow->setTransferringFiles(FALSE);
            if (result < 0)
            {
                mainwindow->tellError(savegamemanager->getMessageErrorTransferring());
            }
        }
    }
    setSavegames();
}


void PSPController::transferSavegamesPSP(QStringList list)
{
    for ( QStringList::Iterator it =list.begin(); it != list.end(); ++it ) 
    {
        //Ask the user if he wants to restore the files
        if (options->getOverwriteSavegames() && savegamemanager->existsPSP(*it))
        {
            if(mainwindow->askYesNo(savegamemanager->getPSPOverwriteMessage(*it)))
            {
                mainwindow->setTransferringFiles(TRUE);
                int result =savegamemanager->transferSavegamePSP(*it);
                mainwindow->setTransferringFiles(FALSE);
                if (result < 0)
                {
                    mainwindow->tellError(savegamemanager->getMessageErrorTransferring());
                }
            }
        }
        else
        {
            mainwindow->setTransferringFiles(TRUE);
            int result =savegamemanager->transferSavegamePSP(*it);
            mainwindow->setTransferringFiles(FALSE);
            if (result < 0)
            {
                mainwindow->tellError(savegamemanager->getMessageErrorTransferring());
            }
        }
    }
    setSavegames();
}


void PSPController::setOverwriteSavegames(bool overwrite)
{
    options->setOverwriteSavegames(overwrite);
}


void PSPController::deleteComputerSavegames(QStringList savegames)
{
    for ( QStringList::Iterator it =savegames.begin(); it != savegames.end(); ++it ) 
    {
        //Ask the user if he wants to delete savegames
        if(options->getOverwriteSavegames())
        {
            if(mainwindow->askYesNo(savegamemanager->getDeleteSavegameMessage(*it)))
            {
                if (!savegamemanager->deleteComputerSavegame(*it))
                {
                    mainwindow->tellError(savegamemanager->getMessageErrorDeleting());
                }
            }
        }
        else
        {
            if (!savegamemanager->deleteComputerSavegame(*it))
            {
                mainwindow->tellError(savegamemanager->getMessageErrorDeleting());
            }
        }
    }
    setSavegames();
}


void PSPController::deletePSPSavegames(QStringList savegames)
{
    for ( QStringList::Iterator it =savegames.begin(); it != savegames.end(); ++it ) 
    {
        //Ask the user if he wants to delete savegames
        if(options->getOverwriteSavegames())
        {
            if(mainwindow->askYesNo(savegamemanager->getDeleteSavegameMessage(*it)))
            {
                if (!savegamemanager->deletePSPSavegame(*it))
                {
                    mainwindow->tellError(savegamemanager->getMessageErrorDeleting());
                }
            }
        }
        else
        {
            if (!savegamemanager->deletePSPSavegame(*it))
            {
                mainwindow->tellError(savegamemanager->getMessageErrorDeleting());
            }
        }
    }
    setSavegames();
}


void PSPController::hideDamage(QString directory)
{
    mainwindow->setTransferringFiles(TRUE);
    int result = pbpmanager->hideDamage(directory);
    mainwindow->setTransferringFiles(FALSE);
    if (result > 0)
    {
        mainwindow->tellMessage(pbpmanager->getMessage(result));
    }
    else
    {
        mainwindow->tellError(pbpmanager->getMessage(result));
    }
}

