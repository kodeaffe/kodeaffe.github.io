/***************************************************************************
 *   Copyright (C) 2005 by Bernat Ràfales                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

//$Revision: 1.4 $

#ifndef PBPMANAGER_H
#define PBPMANAGER_H

#include <qstring.h>
#include <qdir.h>
#include <qobject.h>

#include "pspoptions.h"

/**
  @author Bernat Ràfales
  */
class PBPManager
{

    public:
        PBPManager(PSPOptions *options);
        ~PBPManager();
        int unpack(QString inputFile, QString outDir);
        int pack(QString outputFile, QString inFiles[7]);
        QString programName(QString filename);
        bool copyFolder(QString input, QString output, QString PBPFile);
        bool copyPBP(QString inFile, QString outFile);
        int transferFiles();
        bool checkBackground(QString filename);
        bool checkIcon(QString filename);
        bool checkPMF(QString filename);
        bool checkAT3(QString filename);
        bool checkProgramName(QString name);
        QString validDirectory(QString name);
        QString getMessage(int i);
        QString getDirectoryStripped(QString directory);
        QString getDirectoryNonStripped(QString directory);
        int hideDamage(QString directory);

    private:
        PSPOptions *options;
        u_int32_t le32(u_int32_t bits);
        bool isStrippedDirectory(QString directory);
};

#endif

