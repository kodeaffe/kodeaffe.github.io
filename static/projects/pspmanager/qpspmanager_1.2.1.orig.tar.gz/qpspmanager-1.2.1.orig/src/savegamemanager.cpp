/***************************************************************************
 *   Copyright (C) 2005 by Bernat Ràfales                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

//$Revision: 1.5 $

#include "savegamemanager.h"
#include "filemanager.h"
#include <qfile.h>
#include <qfileinfo.h>
#include <qdatastream.h>
#include <qtextcodec.h>

savegameManager::savegameManager(PSPOptions *options)
{
    this->options = options;
}


savegameManager::~savegameManager()
{
}

QString savegameManager::getName(QString file)
{
    QFile inFile(file);
    if (!inFile.open(IO_ReadOnly))
    {
        return "";
    }
    QDataStream in(&inFile);

    //Signature
    Q_UINT8 signature[4];
    in.readRawBytes((char *)signature, sizeof(signature));
    if ((signature[0] != '\0') || (signature[1] != 'P') || (signature[2] != 'S') || (signature[3] != 'F'))
    {
        return "";
    }
    //Name starts at char number 4784, we've read 4 so far so we need to read the rest of the file
    //and start looking
    //TODO: assure ALL savegame files have the same sections and offsets
    
    char *s = (char *)malloc(inFile.size() - 4);
    in.readRawBytes(s, inFile.size() - 4);
    
    QString title = "";
    unsigned int i = 4780;
    bool end = (s[i] == 0x00);

    while (!end)
    {
        title += s[i];
        i++;
        end = (s[i] == 0x00);
    }
    
    free(s);

    inFile.close();
    return title;
}


QStringList savegameManager::getComputerSavegames()
{
    return getSavegames(options->getSavegameDir());
}



QStringList savegameManager::getPSPSavegames()
{
    return getSavegames(options->getPSPDir() + "/psp/savedata");
}


QStringList savegameManager::getSavegames(QString directory)
{
    QDir dir(directory);
    QStringList result;
    if (dir.exists()) //else we return an empty list
    {
        //Only interested in directories, anything else is trash
        QFileInfoList dirList(*(dir.entryInfoList(QDir::Dirs | QDir::NoSymLinks)));
        //Remove . and .. directories
        dirList.removeFirst();
        dirList.removeFirst();
        QFileInfo *currentDirectory= dirList.first();
        while (currentDirectory != 0)
        {
            addSavegame(currentDirectory, &result);
            currentDirectory = dirList.next();
        }
    }
    return result;
}



void savegameManager::addSavegame(QFileInfo *info, QStringList *list)
{
    //Check is a valid savegame directory
    QFileInfo sfo(info->filePath() + "/param.sfo");
    if (sfo.exists())
    {
        QString saveName = getName(sfo.filePath());
        if (saveName != "") //Valid savegame dir
        {
            list->append(info->filePath() + "/icon0.png");
            list->append(info->fileName() + "-" + saveName + "-" + sfo.lastModified().toString(Qt::LocalDate));
        }
    }
}



bool savegameManager::existsComputer(QString directory)
{
    return existsSavegame(options->getSavegameDir(), directory);
}



bool savegameManager::existsPSP(QString directory)
{
    return existsSavegame(options->getPSPDir() + "/psp/savedata", directory);
}



bool savegameManager::existsSavegame(QString directory, QString savegame)
{
    QFileInfo file(directory + "/" + savegame.section('-', 0, 0) + "/param.sfo");
    return file.exists();
}



QString savegameManager::getComputerOverwriteMessage(QString directory)
{
    QString message1 = QObject::tr("You are going to overwrite\n");
    QString message2 = QObject::tr(" from ");
    QString message3 = QObject::tr("\nover another one from ");
    QString message4 = QObject::tr("\nAre you sure you want to proceed?");
    return (message1 + directory.section('-', 0, 0) + message2 + getDate(options->getPSPDir() + "/psp/savedata", directory).toString(Qt::LocalDate) + message3 + getDate(options->getSavegameDir(), directory).toString(Qt::LocalDate) + message4);
}



QString savegameManager::getPSPOverwriteMessage(QString directory)
{
    QString message1 = QObject::tr("You are going to overwrite\n");
    QString message2 = QObject::tr(" from ");
    QString message3 = QObject::tr("\nover another one from ");
    QString message4 = QObject::tr("\nAre you sure you want to proceed?");
    return (message1 + directory.section('-', 0, 0) + message2 + getDate(options->getSavegameDir(), directory).toString(Qt::LocalDate) + message3 + getDate(options->getPSPDir() + "/psp/savedata", directory).toString(Qt::LocalDate) + message4);
}


QDateTime savegameManager::getDate(QString directory, QString savegame)
{
    QFileInfo file(directory + "/" + savegame.section('-', 0, 0) + "/param.sfo");
    return file.lastModified();
}


bool savegameManager::transferSavegamePSP(QString directory)
{
    return transferSavegame(options->getSavegameDir() + directory.section('-', 0, 0), options->getPSPDir() + "/psp/savedata" + "/" + directory.section('-', 0, 0));
}


bool savegameManager::transferSavegameComputer(QString directory)
{
   return transferSavegame(options->getPSPDir() + "/psp/savedata" + "/" + directory.section('-', 0, 0), options->getSavegameDir() + directory.section('-', 0, 0));
}


bool savegameManager::transferSavegame(QString sourceDirectory, QString destDirectory)
{
    QDir inDir(sourceDirectory);
    QDir outDir(destDirectory);
    if (!outDir.exists())
    {
        if (!outDir.mkdir(destDirectory))
        {
            return FALSE;
        }
    }
    QFileInfoList dirList(*(inDir.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoSymLinks)));
    //Delete . and .. dirs
    dirList.removeFirst();
    dirList.removeFirst();
    return fileManager::copyFiles(outDir, dirList);
}


QString savegameManager::getMessageErrorTransferring()
{
    return QObject::tr("Error transferring savegame");
}



QString savegameManager::getMessageErrorDeleting()
{
    return QObject::tr("Error deleting savegame");
}



bool savegameManager::deleteComputerSavegame(QString directory)
{
    return deleteSavegame(options->getSavegameDir() + directory.section('-', 0, 0));
}


bool savegameManager::deletePSPSavegame(QString directory)
{
   return deleteSavegame(options->getPSPDir() + "/psp/savedata" + "/" + directory.section('-', 0, 0));
}



bool savegameManager::deleteSavegame(QString directory)
{
    return fileManager::deleteDir(directory);
}



QString savegameManager::getDeleteSavegameMessage(QString directory)
{
    QString message1 = QObject::tr("Are you sure you want to delete the ");
    QString message2 = QObject::tr(" savegame?");
    return (message1 + directory.section('-', 0, 0) + message2);
}

