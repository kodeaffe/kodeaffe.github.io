/***************************************************************************
 *   Copyright (C) 2005 by Bernat Ràfales                                  *
 *   qpbpmaker@melindro.com                                                *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <qfiledialog.h>
#include <pspcontroller.h>
#include <qpixmap.h>
#include <qmessagebox.h>
#include <qstringlist.h>
#include "windowabout.h"

PSPController *controller;

void mainWindow::init()
{
    controller = new PSPController(this);
}


void mainWindow::openFile()
{
    QString s = QFileDialog::getOpenFileName(
            ".",
            tr("PBP Files") + " (*.pbp *.PBP)",
            this,
            tr("open file dialog"),
            tr("Choose a PSP executable") );
    if (s != NULL)
    {
        controller->openPBPFile(s);
    }
}


void mainWindow::setIconPix( QString iconFile )
{
    buttonIcon->setPixmap( QPixmap(iconFile) );
}


void mainWindow::setBackgroundPix( QString backgroundFile )
{
    buttonBackground->setPixmap( QPixmap(backgroundFile) );
}


void mainWindow::setIconFileName( QString fileName )
{
    lineIcon->setText(fileName);
}


void mainWindow::setBackgroundFileName( QString fileName )
{
    lineBackground->setText(fileName);
}


void mainWindow::setWindowText( QString caption )
{
    this->setCaption("QPSPManager - " + caption);
}


void mainWindow::setFileName( QString fileName )
{
    lineFile->setText(fileName);
}


void mainWindow::openIconFile()
{
    QString s = QFileDialog::getOpenFileName(
            ".",
            "PNG Files (*.png *.PNG)",
            this,
            tr("open file dialog"),
            tr("Choose an icon file") );
    if (s != NULL)
    {
        controller->openIcon(s);
    }
}


void mainWindow::openBackgroundFile()
{
    QString s = QFileDialog::getOpenFileName(
            ".",
            "PBP Files (*.png *.PNG)",
            this,
            tr("open file dialog"),
            tr("Choose a background file") );
    if (s != NULL)
    {
        controller->openBackground(s);
    }
}


void mainWindow::openPSPDir()
{
    QString s = QFileDialog::getExistingDirectory(
            ".",
            this,
            tr("get existing directory"),
            tr("Choose a directory"),
            TRUE );
    if (s != NULL)
    {
        controller->openPSPDir(s);
    }
}


void mainWindow::hideDamage()
{
    controller->setHideDamage(radioHideYes->isChecked());
}


void mainWindow::checkPSPDir()
{
    controller->checkPSPDir();
}


void mainWindow::setPSPDirOK( bool ok)
{
    pixPSPDirOK->setEnabled(ok);
    pixPSPDirKO->setEnabled(!ok);
}



void mainWindow::savePreferences()
{
    controller->savePreferences();
}


void mainWindow::setPSPDir( QString dir )
{
    linePSPDir->setText(dir);
}


void mainWindow::setHideDamage( bool ok )
{
    radioHideYes->setChecked(ok);
    radioHideNo->setChecked(!ok);
}


void mainWindow::setLabelInfo( QString info )
{
    labelInformation->setText(info);
}


void mainWindow::transferFiles()
{
    controller->transferFiles();
}


void mainWindow::setTransferEnabled( bool enabled )
{
    buttonTransfer->setEnabled(enabled);
}


void mainWindow::help()
{
    windowAbout *about = new windowAbout();
    about->show();
}


void mainWindow::setTransferringFiles( bool transferring )
{
    if (transferring)
    {
        this->setCursor(Qt::WaitCursor);
        this->setEnabled(FALSE);
    }
    else
    {
        this->setCursor(Qt::ArrowCursor);
        this->setEnabled(TRUE);
    }
}


void mainWindow::setProgramName()
{
    controller->setProgramName(lineProgramName->text());
}


void mainWindow::setTextProgramName( QString programName )
{
    lineProgramName->setText(programName);
}


void mainWindow::setPMFFileName( QString fileName )
{
    linePMF->setText(fileName);
}


void mainWindow::setAT3FileName( QString fileName )
{
    lineAT3->setText(fileName);
}


void mainWindow::iconChecked( bool check )
{
    lineIcon->setEnabled(check);
    buttonIcon->setEnabled(check);
    controller->iconEnabled(check);
}


void mainWindow::backgroundChecked( bool check )
{
    lineBackground->setEnabled(check);
    buttonBackground->setEnabled(check);
    controller->backgroundEnabled(check);
}


void mainWindow::PMFChecked( bool check )
{
    linePMF->setEnabled(check);
    buttonPMF->setEnabled(check);
    controller->PMFEnabled(check);
}


void mainWindow::AT3Checked( bool check )
{
    lineAT3->setEnabled(check);
    buttonAT3->setEnabled(check);
    controller->AT3Enabled(check);
}


void mainWindow::openPMFFile()
{
    QString s = QFileDialog::getOpenFileName(
            ".",
            "PMF Files (*.pmf *.PMF)",
            this,
            tr("open file dialog"),
            tr("Choose a PMF file") );
    if (s != NULL)
    {
        controller->openPMF(s);
    }
}


void mainWindow::openAT3File()
{
    QString s = QFileDialog::getOpenFileName(
            ".",
            "AT3 Files (*.at3 *.AT3)",
            this,
            tr("open file dialog"),
            tr("Choose an AT3 file") );
    if (s != NULL)
    {
        controller->openAT3(s);
    }
}


void mainWindow::tellMessage( QString message )
{
QMessageBox::information(this, "QPSPManager",
    message);
}


void mainWindow::tellError( QString message )
{
QMessageBox::critical(this, "QPSPManager",
    message);
}


void mainWindow::setComputerSavegames( QStringList list )
{
    setSavegames(list, listBoxComputer);
}


void mainWindow::setPSPSavegames( QStringList list )
{
    setSavegames(list, listBoxPSP);
}


void mainWindow::setSavegames( QStringList list, QListBox *listBox )
{
    listBox->clear();
    for ( QStringList::Iterator it = list.begin(); it != list.end(); ++it ) 
    {
        QString pixmap = *it;
        ++it;
        listBox->insertItem(QPixmap(pixmap), QString::fromUtf8(*it));
    }
}


void mainWindow::computerToPSP()
{
    controller->transferSavegamesPSP(getSelected(listBoxComputer));
}


void mainWindow::PSPToComputer()
{
    controller->transferSavegamesComputer(getSelected(listBoxPSP));
}


void mainWindow::allToComputer()
{
    controller->transferSavegamesComputer(getItems(listBoxPSP));
}


void mainWindow::allToPSP()
{
    controller->transferSavegamesPSP(getItems(listBoxComputer));
}


QStringList mainWindow::getSelected( QListBox *list )
{
    QStringList result;
    for(uint i = 0; i < list->count(); i++)
    {
        if (list->isSelected(i))
        {
            result.append(list->text(i));
        }
    }
    return result;
}


QStringList mainWindow::getItems( QListBox * list )
{
    QStringList result;
    for(uint i = 0; i < list->count(); i++)
    {
        result.append(list->text(i));
    }
    return result;
}


void mainWindow::overwriteSavegames()
{
    controller->setOverwriteSavegames(radioOverwriteYes->isChecked());
}


void mainWindow::setOverwrite( bool overwrite )
{
    radioOverwriteYes->setChecked(overwrite);
    radioOverwriteNo->setChecked(!overwrite);
}


bool mainWindow::askYesNo(QString message)
{
    switch (QMessageBox::question(
                this,
                "QPSPManager",
                 message,
                QMessageBox::Yes, QMessageBox::No))
    {
        case QMessageBox::Yes:
            {
                return TRUE;
            }
        case QMessageBox::No:
            {
                return FALSE;
            }
        default:
            {
                return FALSE;
            }
    }
}


void mainWindow::deleteSavegamesComputer()
{
    controller->deleteComputerSavegames(getSelected(listBoxComputer));
}


void mainWindow::deleteSavegamesPSP()
{
    controller->deletePSPSavegames(getSelected(listBoxPSP));
}


void mainWindow::disablePBP()
{
    this->tabWidget->showPage( this->TabPage );
    this->tabWidget->setTabEnabled( this->tab, FALSE );
    this->tellMessage( tr( "Your PSP is too fresh. There is no hack to put homebrew software on your device, yet.\nSection PBP File was disabled!" ));
}


void mainWindow::disableSavegames()
{
    buttonRight->setEnabled(FALSE);
    button2Right->setEnabled(FALSE);
    buttonLeft->setEnabled(FALSE);
    button2Left->setEnabled(FALSE);
    buttonDeleteComputer->setEnabled(FALSE);
    buttonDeletePSP->setEnabled(FALSE);
}


void mainWindow::enableSavegames()
{
    buttonRight->setEnabled(TRUE);
    button2Right->setEnabled(TRUE);
    buttonLeft->setEnabled(TRUE);
    button2Left->setEnabled(TRUE);
    buttonDeleteComputer->setEnabled(TRUE);
    buttonDeletePSP->setEnabled(TRUE);
}


void mainWindow::clearLists()
{
    listBoxComputer->clear();
    listBoxPSP->clear();
}


void mainWindow::hideDamageDirectory()
{
    QString s = QFileDialog::getExistingDirectory(
            ".",
            this,
            tr("get existing directory"),
            tr("Choose the directory"),
            TRUE );
    if (s != NULL)
    {
        controller->hideDamage(s);
    }
}


void mainWindow::hideDamageEnable( bool enable )
{
    buttonHideDamage->setEnabled(enable);
}
