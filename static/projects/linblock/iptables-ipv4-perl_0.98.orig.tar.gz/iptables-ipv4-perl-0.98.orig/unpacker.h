#include "local_types.h"

HV *ipt_do_unpack(ENTRY *, HANDLE *);
