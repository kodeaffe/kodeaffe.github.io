/***************************************************************************
 *   Copyright (C) 2005 by Bernat Ràfales                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

//$Revision: 1.2 $

#ifndef PSPOPTIONS_H
#define PSPOPTIONS_H

#include <qsettings.h>
#include <qfile.h>
#include <qdir.h>

/**
  @author Bernat Ràfales
  */

class PSPOptions
{

    public:
        PSPOptions();
        ~PSPOptions();
        void setOutputDir(QString dir);
        QString getOutputDir();
        void setSettingsSet(bool set);
        bool getSettingsSet();
        void setHideDamage(bool hide);
        bool getHideDamage();
        void setPSPDir(QString dir);
        QString getPSPDir();
        void setFileName(QString file);
        QString getFileName();
        void setIconFile(QString file);
        QString getIconFile();
        void setBackgroundFile(QString file);
        QString getBackgroundFile();
        void setPMFFile(QString file);
        QString getPMFFile();
        void setAT3File(QString file);
        QString getAT3File();
        QString getTempDir();
        void setTempDir(QString dir);
        QString getSavegameDir();
        void setSavegameDir(QString dir);
        void setOutputDirOK(bool ok);
        void setPSPDirOK(bool ok);
        void setPSPDeviceOK(bool ok);
        void setProgramName(QString name);
        QString getProgramName();
        bool checkPSPDir();
        bool checkPSPDevice();
        void setWantIcon(bool icon);
        bool getWantIcon();
        void setWantBackground(bool background);
        bool getWantBackground();
        void setWantSound(bool sound);
        bool getWantSound();
        void setWantMovie(bool movie);
        bool getWantMovie();
        bool getOverwriteSavegames();
        void setOverwriteSavegames(bool overwrite);
        void savePreferences();

    private:

        //Attributes
        bool settingsSet;
        //Global options
        QString outputDir; //PBP dir
        QString savegameDir;
        QString tempDir;
        bool hideDamage;
        QString PSPDir;
        bool outputDirOK;
        bool PSPDirOK;
        bool PSPDeviceOK;
        bool overwriteSavegames;
        //One time options
        QString programName;
        QString fileName;
        QString iconFile;
        QString backgroundFile;
        QString PMFFile;
        QString AT3File;
        bool wantIcon;
        bool wantBackground;
        bool wantMovie;
        bool wantSound;
        //Functions
        bool checkFile(QString fileName);
        bool checkDir(QString dir);
};

#endif

