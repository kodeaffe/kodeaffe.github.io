<!DOCTYPE TS><TS>
<context>
    <name>QObject</name>
    <message>
        <source>Files were correctly transferred.</source>
        <translation>文件已�
确传输。</translation>
    </message>
    <message>
        <source>PBP file unpacked successfully.</source>
        <translation>PBP文件已�
功解开。</translation>
    </message>
    <message>
        <source>Directories successfully created. Now you can copy them to
 your PSP</source>
        <translation type="obsolete">目录成�
建立。现在你可以
将它们复制进PSP</translation>
    </message>
    <message>
        <source>Necessary files not found. Open the PBP file again.</source>
        <translation>没有找�
必要的文件。请再
次打开PBP文件。</translation>
    </message>
    <message>
        <source>Directory already exists. Delete it first.</source>
        <translation>目录已�
在。请先将其删除
。</translation>
    </message>
    <message>
        <source>Error creating directories, check permissions in the PSP d
irectory.</source>
        <translation type="obsolete">目录创�
错误，请检查PSP目�
的权限。</translation>
    </message>
    <message>
        <source>Error packing the files. Check the files and try again.</source>
        <translation>文件打�
出错。请检查文件
并重试一次。</translation>
    </message>
    <message>
        <source>Error copying files.</source>
        <translation>文件复�
出错。</translation>
    </message>
    <message>
        <source>Error opening the PBP file for reading.</source>
        <translation>打开读�
PBP文件时出错。</translation>
    </message>
    <message>
        <source>The file selected is not a PBP file.</source>
        <translation>选择的�
件不是PBP文件。</translation>
    </message>
    <message>
        <source>Error creating temporary files. Check permissions on the t
emp directory.</source>
        <translation type="obsolete">创建临�
文件时出错。请检
查临时目录的权限�
</translation>
    </message>
    <message>
        <source>Could not find the &quot;pair&quot; directory. Please chec
k both directories are in the same place.</source>
        <translation type="obsolete">无法找�
“配对”目录。请
确保两个目录在相�
的地方。</translation>
    </message>
    <message>
        <source>Unknown error.</source>
        <translation>未知错�
。</translation>
    </message>
    <message>
        <source>Destination files already exists. Do you want to overwrite
 them?</source>
        <translation type="obsolete">目标文�
已存在。要进行覆
盖吗？</translation>
    </message>
    <message>
        <source>You are going to overwrite
</source>
        <translation>将要提�
同名存档</translation>
    </message>
    <message>
        <source> from </source>
        <translation>将</translation>
    </message>
    <message>
        <source>
over another one from </source>
        <translation>替换为</translation>
    </message>
    <message>
        <source>
Are you sure you want to proceed?</source>
        <translation>你确定�
继续吗？</translation>
    </message>
    <message>
        <source>Error transferring savegame</source>
        <translation>传输错�
：游戏存档</translation>
    </message>
    <message>
        <source>Error deleting savegame</source>
        <translation>删除错�
：游戏存档</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the </source>
        <translation>你确定�
删除</translation>
    </message>
    <message>
        <source> savegame?</source>
        <translation>存档吗�
</translation>
    </message>
    <message>
        <source>Directories successfully created. Now you can copy them to your PSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error creating directories, check permissions in the PSP directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error creating temporary files. Check permissions on the temp directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the &quot;pair&quot; directory. Please check both directories are in the same place.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Destination files already exists. Do you want to overwrite them?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>mainWindow</name>
    <message>
        <source>QPSPManager</source>
        <translation>QPSPManager</translation>
    </message>
    <message>
        <source>PBP File</source>
        <translation>PBP文件</translation>
    </message>
    <message>
        <source>AT3 file</source>
        <translation>AT3文件</translation>
    </message>
    <message>
        <source>Open an AT3 file</source>
        <translation>打开一�
AT3文件</translation>
    </message>
    <message>
        <source>PBP file</source>
        <translation>PBP文件</translation>
    </message>
    <message>
        <source>Open a PBP file</source>
        <translation>打开一�
PBP文件</translation>
    </message>
    <message>
        <source>PMF file</source>
        <translation>PMF文件</translation>
    </message>
    <message>
        <source>Open a PMF file</source>
        <translation>打开一�
PMF文件</translation>
    </message>
    <message>
        <source>Icon file</source>
        <translation>图标文�
</translation>
    </message>
    <message>
        <source>Icon File</source>
        <translation>图标文�
</translation>
    </message>
    <message>
        <source>Select an icon file</source>
        <translation>请选择�
个图标文件</translation>
    </message>
    <message>
        <source>Background file</source>
        <translation>背景文�
</translation>
    </message>
    <message>
        <source>Background File</source>
        <translation>背景文�
</translation>
    </message>
    <message>
        <source>Select a background file</source>
        <translation>选择一�
背景文件</translation>
    </message>
    <message>
        <source>Program Name:</source>
        <translation>程序名�
：</translation>
    </message>
    <message>
        <source>Write the program name here</source>
        <translation>请在这�
填入程序名称</translation>
    </message>
    <message>
        <source>Transfer files to PSP</source>
        <translation>将文件�
输到PSP中</translation>
    </message>
    <message>
        <source>Transfer the files</source>
        <translation>传输文�
</translation>
    </message>
    <message>
        <source>Hide damage of an existing directory</source>
        <translation>隐藏破�
数据</translation>
    </message>
    <message>
        <source>Savegames</source>
        <translation>游戏存�
</translation>
    </message>
    <message>
        <source>Computer</source>
        <translation>计算机</translation>
    </message>
    <message>
        <source>New Item</source>
        <translation>新项目</translation>
    </message>
    <message>
        <source>Delete savegames from Computer</source>
        <translation>从计算�
中删除游戏存档</translation>
    </message>
    <message>
        <source>Transfer selected savegames to PSP</source>
        <translation>将选中�
存档传输到PSP中</translation>
    </message>
    <message>
        <source>Transfer selected savegames to Computer</source>
        <translation>将选中�
存档传输到计算机
中</translation>
    </message>
    <message>
        <source>Transfer all savegames to PSP</source>
        <translation>将所有�
档传输到PSP中</translation>
    </message>
    <message>
        <source>Transfer all savegames to Computer</source>
        <translation>将所有�
档传输到计算机中
</translation>
    </message>
    <message>
        <source>PSP</source>
        <translation>PSP</translation>
    </message>
    <message>
        <source>Delete savegames from PSP</source>
        <translation>从PSP中删�
存档</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source>PSP Directory:</source>
        <translation>PSP目录：</translation>
    </message>
    <message>
        <source>Select the root PSP directory</source>
        <translation>请选择PSP�
根目录</translation>
    </message>
    <message>
        <source>Check</source>
        <translation>检查</translation>
    </message>
    <message>
        <source>Check if the current PSP directory is correct</source>
        <translation>检查当�
PSP目录是否正确</translation>
    </message>
    <message>
        <source>Hide PBP damaged files</source>
        <translation>隐藏破�
数据图标</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <source>Hide the damaged data in the PSP</source>
        <translation>隐藏PSP中�
破损数据图标</translation>
    </message>
    <message>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <source>Do not hide the damaged data in the PSP</source>
        <translation>不隐藏PSP�
的破损数据图标</translation>
    </message>
    <message>
        <source>Ask deleting/overwriting savegames</source>
        <translation>删除/覆�
存档时进行提示</translation>
    </message>
    <message>
        <source>Save Preferences</source>
        <translation>保存首�
项</translation>
    </message>
    <message>
        <source>Save the options for further uses</source>
        <translation>保存选�
供以后使用</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>关于...</translation>
    </message>
    <message>
        <source>PBP Files</source>
        <translation>PBP文件</translation>
    </message>
    <message>
        <source>open file dialog</source>
        <translation>打开文�
对话框</translation>
    </message>
    <message>
        <source>Choose a PSP executable</source>
        <translation>选择一�
PSP执行文件</translation>
    </message>
    <message>
        <source>Choose an icon file</source>
        <translation>选择一�
图标文件</translation>
    </message>
    <message>
        <source>Choose a background file</source>
        <translation>选择一�
背景文件</translation>
    </message>
    <message>
        <source>get existing directory</source>
        <translation>获取已�
在的目录</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>选择一�
目录</translation>
    </message>
    <message>
        <source>Choose a PMF file</source>
        <translation>选择一�
PMF文件</translation>
    </message>
    <message>
        <source>Choose an AT3 file</source>
        <translation>选择一�
AT3文件</translation>
    </message>
    <message>
        <source>Your PSP is too fresh. There is no hack to put homebrew so
ftware on your device, yet.
Section PBP File was disabled!</source>
        <translation type="obsolete">你的PSP版�
过高。无法在你�
PSP上运行自制软件�

PBP文件模块被禁用！
</translation>
    </message>
    <message>
        <source>Choose the directory</source>
        <translation>选择目�
</translation>
    </message>
    <message>
        <source>Some options are not correctly set</source>
        <translation>某些选�
没有正确设置</translation>
    </message>
    <message>
        <source>You must open a PBP file before transfering files</source>
        <translation>你必须�
选择一个PBP文件才�
进行文件传输</translation>
    </message>
    <message>
        <source>You must set the PSP directory before transfering files</source>
        <translation>你必须�
设置PSP目录才能进�
文件传输</translation>
    </message>
    <message>
        <source>Files will be transferred to </source>
        <translation>文件将�
传输到</translation>
    </message>
    <message>
        <source>The program name is not valid</source>
        <translation>程序名�
正确</translation>
    </message>
    <message>
        <source>Invalid background image. Check is 480x272 in size</source>
        <translation>背景图�
无效。请确定图片
大小为480x272</translation>
    </message>
    <message>
        <source>Invalid PMF file</source>
        <translation>无效的PMF�
件</translation>
    </message>
    <message>
        <source>Invalid AT3 file</source>
        <translation>无效的AT3�
件</translation>
    </message>
    <message>
        <source>Your PSP is too fresh. There is no hack to put homebrew software on your device, yet.
Section PBP File was disabled!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>windowAbout</name>
    <message>
        <source>About/Help</source>
        <translation>关于/帮�
</translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;html&gt;
&lt;head&gt;
<byte value="x9"/>&lt;meta HTTP-EQUIV=&quot;CONTENT-TYPE&quot; CONTENT
=&quot;text/html; charset=utf-8&quot;&gt;
<byte value="x9"/>&lt;title&gt;QPSPManager: About&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1 align=center&gt;QPSPManager&lt;/h1&gt;&lt;p align=center&gt;
The Linux PSP File Manager&lt;/p&gt;
&lt;p align=center&gt;
version 1.2
&lt;/p&gt;
&lt;p align=center&gt;
(C) 2005 Bernat Ràfales Mulet
&lt;/p&gt;
&lt;p align=center&gt;
&lt;a href=&quot;http://qpspmanager.sourceforge.net&quot;&gt;http://qpspm
anager.sourceforge.net&lt;/a&gt;
&lt;/p&gt;
&lt;h2&gt;Information&lt;/h2&gt;
&lt;p&gt;
QPSPManager is a PSP File manager for Linux. It&apos;s intended to use as a
 user friendly GUI to the known tedious pack and unpack processes of the PS
P PBP files, directory generation and further copy into the PSP in order to
 execute those files in firmwares 1.50, providing some other features as se
lecting a custom icon or background file to show on the menu. It also provi
des support for backuping savegames on the computer.
&lt;/p&gt;
&lt;h2&gt;Authors&lt;/h2&gt;
&lt;p&gt;
This program was designed and developed by Bernat Ràfales Mulet.
&lt;h2&gt;Report bugs / Feedback / Contact author&lt;/h2&gt;
&lt;p&gt;
Please feel free to report bugs, feedbacks or suggestions to the author at 
&lt;a href=&quot;mailto:the_bell@users.sourceforge.net&quot;&gt;the_bell@
users.sourceforge.net&lt;/a&gt;.
&lt;/p&gt;
&lt;p&gt;
Don&apos;t forget to visit the Official home page at &lt;a href=&quot;htt
p://qpspmanager.sourceforge.net&quot;&gt;http://qpspmanager.sourceforge.net
&lt;/a&gt; for updates or news about QPSPManager.
&lt;/p&gt;
&lt;h2&gt;Special thanks&lt;/h2&gt;
&lt;p&gt;
Special thanks go to Dan Peori (&lt;a href=&quot;mailto:peori@oopo.net&quot;&gt;peori@oopo.net&lt;/a&gt;) for writing the pack and unpack programs w
hich helped me to understand the structure of the PBP file format.
&lt;/p&gt;
&lt;p&gt;
Special thanks to Sebastian Henschel and Philippe Maes for the distribution
 files and support.
&lt;/p&gt;
&lt;h2&gt;License&lt;/h2&gt;
&lt;p&gt;
This program is distributed under the terms of the GPL v2. Please read the 
LICENSE file included in the distribution of the program for more informati
on.
&lt;/p&gt;
&lt;p&gt;
This program comes with NO WARRANTY and is distributed AS IS, use it at you
r own risk. The author takes no responsability of the possible damage cause
d to your computer or your PSP.
&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt; &lt;head&gt; &lt;meta 
HTTP-EQUIV=&quot;CONTENT-TYPE&quot; CONTENT=&quot;text/html; charset=
utf-8&quot;&gt; &lt;title&gt;
QPSPManager: About&lt;/title&gt; &lt;/head&gt; &lt;body&gt; &lt;h1 align=
center&gt;QPSPManager&lt;/h1&gt;&lt;p align=center&gt; 
Linux下的PSP文件管理器&lt;
/p&gt; &lt;p align=center&gt; 1.2 版&lt;/p&gt; &lt;p align=cente
r&gt; (C) 2005 Bernat 
Ràfales Mulet &lt;/p&gt; &lt;p align=center&gt; &lt;a href=&quot;h
ttp://qpspmanager.sourceforge.net&quot;&gt;
http://qpspmanager.sourceforge.net&lt;/a&gt; &lt;/p&gt; &lt;h2&gt;信
息&lt;/h2&gt; 
&lt;p&gt; QPSPManager是Linux系统下的PSP
文件管理程序。它�
目标是用友好的�
形界面来解决当前
繁琐的PSP专用PBP文件�
式的解压和打包、
目录生成和复制到PSP
中，以使1.50版PSP能够�
行这些文件的过�
。此外软件还带有
选择自定义图标或�
景的功能，以及�
游戏存档备份到计
算机中的功能。&lt;/p&gt; &lt;h2&gt;
作者&lt;/h2&gt; &lt;p&gt; 该软件�
由Bernat Ràfales Mulet设计和开
发的。&lt;h2&gt;报告bug / 信�
反馈 / 联系作者&lt;/h2&gt; 
&lt;p&gt; 
请报告你发现的bug，
或者你的反馈、建�
到作者的信箱：&lt;a 
href=&quot;mailto:the_bell@users.sourceforge.net&quot;&gt;the_bell@users.
sourceforge.net&lt;/a&gt; &lt;/p&gt; &lt;p&gt; 
请记得经常访问官�
网站 &lt;a href=&quot;http://qpspmanager.sourceforge.
net&quot;&gt;
http://qpspmanager.sourceforge.net&lt;/a&gt; 查找新�
的QPSPManager. &lt;/p&gt; &lt;h2&gt;特别�
谢&lt;/h2&gt; &lt;p&gt; 
特别感谢Dan Peori （&lt;a href=&quot;m
ailto:peori@oopo.net&quot;&gt;peori@oopo.net&lt;/a&gt;）编�
的压缩和解压程�
，它帮助了我理解
PBP文件格式的结构。
 &lt;/p&gt; &lt;p&gt; 
特别感谢Sebastian Henschel和Philippe Mae
s发布文件和提供支
持。&lt;/p&gt; &lt;h2&gt;许可&lt;/h2&gt; 
&lt;p&gt; 该程序是在遵从GP
L v2条款的前提下进�
发布的。请查看随
程序发布的LICENSE文件�
获得更多信息。&lt;/p
&gt; 
&lt;p&gt;该程序没有任何�
保，并且按其原�
发布。请自行承担
使用后造成的后果�
作者对此程序可�
对你的计算机及PSP�
成的损害不负任何
责任。&lt;/p&gt;

&lt;/body&gt; &lt;/html&gt;</translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;html&gt;
&lt;head&gt;
<byte value="x9"/>&lt;meta HTTP-EQUIV=&quot;CONTENT-TYPE&quot; CONTENT=&quot;text/html; charset=utf-8&quot;&gt;
<byte value="x9"/>&lt;title&gt;QPSPManager: About&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1 align=center&gt;QPSPManager&lt;/h1&gt;&lt;p align=center&gt;
The Linux PSP File Manager&lt;/p&gt;
&lt;p align=center&gt;
version 1.2
&lt;/p&gt;
&lt;p align=center&gt;
(C) 2005 Bernat Ràfales Mulet
&lt;/p&gt;
&lt;p align=center&gt;
&lt;a href=&quot;http://qpspmanager.sourceforge.net&quot;&gt;http://qpspmanager.sourceforge.net&lt;/a&gt;
&lt;/p&gt;
&lt;h2&gt;Information&lt;/h2&gt;
&lt;p&gt;
QPSPManager is a PSP File manager for Linux. It&apos;s intended to use as a user friendly GUI to the known tedious pack and unpack processes of the PSP PBP files, directory generation and further copy into the PSP in order to execute those files in firmwares 1.50, providing some other features as selecting a custom icon or background file to show on the menu. It also provides support for backuping savegames on the computer.
&lt;/p&gt;
&lt;h2&gt;Authors&lt;/h2&gt;
&lt;p&gt;
This program was designed and developed by Bernat Ràfales Mulet.
&lt;h2&gt;Report bugs / Feedback / Contact author&lt;/h2&gt;
&lt;p&gt;
Please feel free to report bugs, feedbacks or suggestions to the author at &lt;a href=&quot;mailto:the_bell@users.sourceforge.net&quot;&gt;the_bell@users.sourceforge.net&lt;/a&gt;.
&lt;/p&gt;
&lt;p&gt;
Don&apos;t forget to visit the Official home page at &lt;a href=&quot;http://qpspmanager.sourceforge.net&quot;&gt;http://qpspmanager.sourceforge.net&lt;/a&gt; for updates or news about QPSPManager.
&lt;/p&gt;
&lt;h2&gt;Special thanks&lt;/h2&gt;
&lt;p&gt;
Special thanks go to Dan Peori (&lt;a href=&quot;mailto:peori@oopo.net&quot;&gt;peori@oopo.net&lt;/a&gt;) for writing the pack and unpack programs which helped me to understand the structure of the PBP file format.
&lt;/p&gt;
&lt;p&gt;
Special thanks to Sebastian Henschel and Philippe Maes for the distribution files and support.
&lt;/p&gt;
&lt;h2&gt;License&lt;/h2&gt;
&lt;p&gt;
This program is distributed under the terms of the GPL v2. Please read the LICENSE file included in the distribution of the program for more information.
&lt;/p&gt;
&lt;p&gt;
This program comes with NO WARRANTY and is distributed AS IS, use it at your own risk. The author takes no responsability of the possible damage caused to your computer or your PSP.
&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
