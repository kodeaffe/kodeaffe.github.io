<!DOCTYPE TS><TS>
<context>
    <name>QObject</name>
    <message>
        <source>Files were correctly transferred.</source>
        <translation>Los ficheros se han transferido correctamente.</translation>
    </message>
    <message>
        <source>PBP file unpacked successfully.</source>
        <translation>El archivo PBP se ha desempaquetado con éxito.</translation>
    </message>
    <message>
        <source>Directories successfully created. Now you can copy them to your PSP</source>
        <translation>Directorios creados con éxito. Ahora ya puedes copiarlos a tu PSP</translation>
    </message>
    <message>
        <source>Necessary files not found. Open the PBP file again.</source>
        <translation>No se han encontrado los ficheros necesarios. Abre el fichero PBP de nuevo.</translation>
    </message>
    <message>
        <source>Directory already exists. Delete it first.</source>
        <translation>El directorio ya existe. Bórralo antes.</translation>
    </message>
    <message>
        <source>Error creating directories, check permissions in the PSP directory.</source>
        <translation>Error creando directorios. Comprueba si los permisos del directorio PSP son correctos.</translation>
    </message>
    <message>
        <source>Error packing the files. Check the files and try again.</source>
        <translation>Error empaquetando los ficheros. Comprueba los ficheros e inténtalo de nuevo.</translation>
    </message>
    <message>
        <source>Error copying files.</source>
        <translation>Error copiando los ficheros.</translation>
    </message>
    <message>
        <source>Error opening the PBP file for reading.</source>
        <translation>Error al abrir el fichero PBP para hacer una lectura.</translation>
    </message>
    <message>
        <source>The file selected is not a PBP file.</source>
        <translation>El fichero seleccionado no es un fichero PBP.</translation>
    </message>
    <message>
        <source>Error creating temporary files. Check permissions on the temp directory.</source>
        <translation>Error al crear los ficheros temporales. Comprueba los permisos del directorio temporal.</translation>
    </message>
    <message>
        <source>Could not find the &quot;pair&quot; directory. Please check both directories are in the same place.</source>
        <translation>No se ha podido encontrar la pareja de directorios (con % y sin %). Por favor, comprueba si los dos directorios están en el mismo lugar.</translation>
    </message>
    <message>
        <source>Unknown error.</source>
        <translation>Error desconocido.</translation>
    </message>
    <message>
        <source>Destination files already exists. Do you want to overwrite them?</source>
        <translation>Los ficheros de destino ya existen. ¿Quieres sobreescribirlos?</translation>
    </message>
    <message>
        <source>You are going to overwrite
</source>
        <translation>Vas a sobreescribir
</translation>
    </message>
    <message>
        <source> from </source>
        <translation> desde </translation>
    </message>
    <message>
        <source>
over another one from </source>
        <translation>
copiándolo encima de </translation>
    </message>
    <message>
        <source>
Are you sure you want to proceed?</source>
        <translation>
¿Seguro que quieres continuar?</translation>
    </message>
    <message>
        <source>Error transferring savegame</source>
        <translation>Error al transferir la partida guardada</translation>
    </message>
    <message>
        <source>Error deleting savegame</source>
        <translation>Error al borrar la partida guardada</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the </source>
        <translation>¿Seguro que quieres borrar la partida guardada </translation>
    </message>
    <message>
        <source> savegame?</source>
        <translation> ?</translation>
    </message>
</context>
<context>
    <name>mainWindow</name>
    <message>
        <source>QPSPManager</source>
        <translation>QPSPManager</translation>
    </message>
    <message>
        <source>PBP File</source>
        <translation>Fichero PBP</translation>
    </message>
    <message>
        <source>AT3 file</source>
        <translation>Fichero AT3</translation>
    </message>
    <message>
        <source>Open an AT3 file</source>
        <translation>Abre un fichero AT3</translation>
    </message>
    <message>
        <source>PBP file</source>
        <translation>Fichero PBP</translation>
    </message>
    <message>
        <source>Open a PBP file</source>
        <translation>Abre un fichero PBP</translation>
    </message>
    <message>
        <source>PMF file</source>
        <translation>Fichero PMF</translation>
    </message>
    <message>
        <source>Open a PMF file</source>
        <translation>Abre un fichero PMF</translation>
    </message>
    <message>
        <source>Icon file</source>
        <translation>Icono</translation>
    </message>
    <message>
        <source>Icon File</source>
        <translation>Icono</translation>
    </message>
    <message>
        <source>Select an icon file</source>
        <translation>Selecciona un icono</translation>
    </message>
    <message>
        <source>Background file</source>
        <translation>Fondo de pantalla</translation>
    </message>
    <message>
        <source>Background File</source>
        <translation>Fondo de pantalla</translation>
    </message>
    <message>
        <source>Select a background file</source>
        <translation>Selecciona un fichero para el fondo de pantalla</translation>
    </message>
    <message>
        <source>Program Name:</source>
        <translation>Nombre del programa:</translation>
    </message>
    <message>
        <source>Write the program name here</source>
        <translation>Escribe aquí el nombre del programa</translation>
    </message>
    <message>
        <source>Transfer files to PSP</source>
        <translation>Transferir ficheros a la PSP</translation>
    </message>
    <message>
        <source>Transfer the files</source>
        <translation>Transferir los ficheros</translation>
    </message>
    <message>
        <source>Hide damage of an existing directory</source>
        <translation>Ocultar los datos dañados de un directorio ya existente</translation>
    </message>
    <message>
        <source>Savegames</source>
        <translation>Partidas guardadas</translation>
    </message>
    <message>
        <source>Computer</source>
        <translation>Ordenador</translation>
    </message>
    <message>
        <source>New Item</source>
        <translation>Nuevo ítem</translation>
    </message>
    <message>
        <source>Delete savegames from Computer</source>
        <translation>Borrar las partidas guardadas del Ordenador</translation>
    </message>
    <message>
        <source>Transfer selected savegames to PSP</source>
        <translation>Transferir las partidas guardadas seleccionadas a la PSP</translation>
    </message>
    <message>
        <source>Transfer selected savegames to Computer</source>
        <translation>Transferir las partidas guardadas seleccionadas al Ordenador</translation>
    </message>
    <message>
        <source>Transfer all savegames to PSP</source>
        <translation>Transferir todas las partidas guardadas a la PSP</translation>
    </message>
    <message>
        <source>Transfer all savegames to Computer</source>
        <translation>Transferir todas las partidas guardadas al Ordenador</translation>
    </message>
    <message>
        <source>PSP</source>
        <translation>PSP</translation>
    </message>
    <message>
        <source>Delete savegames from PSP</source>
        <translation>Borrar las partidas guardadas de la PSP</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>PSP Directory:</source>
        <translation>Directorio PSP:</translation>
    </message>
    <message>
        <source>Select the root PSP directory</source>
        <translation>Selecciona el directorio raíz de tu PSP</translation>
    </message>
    <message>
        <source>Check</source>
        <translation>Comprobar</translation>
    </message>
    <message>
        <source>Check if the current PSP directory is correct</source>
        <translation>Comprueba si el directorio PSP actual es correcto</translation>
    </message>
    <message>
        <source>Hide PBP damaged files</source>
        <translation>Ocultar los ficheros PBP que estén dañados</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>Hide the damaged data in the PSP</source>
        <translation>Ocultar los datos dañados en la PSP</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Do not hide the damaged data in the PSP</source>
        <translation>No ocultar los datos dañados en la PSP</translation>
    </message>
    <message>
        <source>Ask deleting/overwriting savegames</source>
        <translation>Preguntar siempre antes de borrar/sobreescribir las partidas guardadas</translation>
    </message>
    <message>
        <source>Save Preferences</source>
        <translation>Guardar Preferencias</translation>
    </message>
    <message>
        <source>Save the options for further uses</source>
        <translation>Guarda las opciones para posteriores usos</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <source>PBP Files</source>
        <translation>Ficheros PBP</translation>
    </message>
    <message>
        <source>open file dialog</source>
        <translation>abrir la ventana de selección de ficheros</translation>
    </message>
    <message>
        <source>Choose a PSP executable</source>
        <translation>Selecciona un fichero ejecutable de PSP</translation>
    </message>
    <message>
        <source>Choose an icon file</source>
        <translation>Selecciona un icono</translation>
    </message>
    <message>
        <source>Choose a background file</source>
        <translation>Selecciona un fondo de pantalla</translation>
    </message>
    <message>
        <source>get existing directory</source>
        <translation>obtener el directorio ya existente</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Selecciona un directorio</translation>
    </message>
    <message>
        <source>Choose a PMF file</source>
        <translation>Selecciona un fichero PMF</translation>
    </message>
    <message>
        <source>Choose an AT3 file</source>
        <translation>Selecciona un fichero AT3</translation>
    </message>
    <message>
        <source>Your PSP is too fresh. There is no hack to put homebrew software on your device, yet.
Section PBP File was disabled!</source>
        <translation>Tu PSP es demasiado nueva. No existe todavía ningún hack que permita ponerle software casero.
¡El apartado Fichero PBP se ha inhabilitado!</translation>
    </message>
    <message>
        <source>Choose the directory</source>
        <translation>Selecciona un directorio</translation>
    </message>
    <message>
        <source>Some options are not correctly set</source>
        <translation>Algunas opciones ya introducidas no son correctas</translation>
    </message>
    <message>
        <source>You must open a PBP file before transfering files</source>
        <translation>Debes abrir un fichero PBP antes de transferir ficheros</translation>
    </message>
    <message>
        <source>You must set the PSP directory before transfering files</source>
        <translation>Debes configurar el directorio PSP antes de transferir ficheros</translation>
    </message>
    <message>
        <source>Files will be transferred to </source>
        <translation>Los ficheros se transferirán a </translation>
    </message>
    <message>
        <source>The program name is not valid</source>
        <translation>El nombre del programa no es válido</translation>
    </message>
    <message>
        <source>Invalid background image. Check is 480x272 in size</source>
        <translation>El fondo de pantalla no es válido. Comprueba si su tamaño es 480x272</translation>
    </message>
    <message>
        <source>Invalid PMF file</source>
        <translation>Fichero PMF no válido</translation>
    </message>
    <message>
        <source>Invalid AT3 file</source>
        <translation>Fichero AT3 no válido</translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>windowAbout</name>
    <message>
        <source>About/Help</source>
        <translation>Acerca de/Ayuda</translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;html&gt;
&lt;head&gt;
<byte value="x9"/>&lt;meta HTTP-EQUIV=&quot;CONTENT-TYPE&quot; CONTENT=&quot;text/html; charset=utf-8&quot;&gt;
<byte value="x9"/>&lt;title&gt;QPSPManager: About&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1 align=center&gt;QPSPManager&lt;/h1&gt;&lt;p align=center&gt;
The Linux PSP File Manager&lt;/p&gt;
&lt;p align=center&gt;
version 1.2
&lt;/p&gt;
&lt;p align=center&gt;
(C) 2005 Bernat Ràfales Mulet
&lt;/p&gt;
&lt;p align=center&gt;
&lt;a href=&quot;http://qpspmanager.sourceforge.net&quot;&gt;http://qpspmanager.sourceforge.net&lt;/a&gt;
&lt;/p&gt;
&lt;h2&gt;Information&lt;/h2&gt;
&lt;p&gt;
QPSPManager is a PSP File manager for Linux. It&apos;s intended to use as a user friendly GUI to the known tedious pack and unpack processes of the PSP PBP files, directory generation and further copy into the PSP in order to execute those files in firmwares 1.50, providing some other features as selecting a custom icon or background file to show on the menu. It also provides support for backuping savegames on the computer.
&lt;/p&gt;
&lt;h2&gt;Authors&lt;/h2&gt;
&lt;p&gt;
This program was designed and developed by Bernat Ràfales Mulet.
&lt;h2&gt;Report bugs / Feedback / Contact author&lt;/h2&gt;
&lt;p&gt;
Please feel free to report bugs, feedbacks or suggestions to the author at &lt;a href=&quot;mailto:the_bell@users.sourceforge.net&quot;&gt;the_bell@users.sourceforge.net&lt;/a&gt;.
&lt;/p&gt;
&lt;p&gt;
Don&apos;t forget to visit the Official home page at &lt;a href=&quot;http://qpspmanager.sourceforge.net&quot;&gt;http://qpspmanager.sourceforge.net&lt;/a&gt; for updates or news about QPSPManager.
&lt;/p&gt;
&lt;h2&gt;Special thanks&lt;/h2&gt;
&lt;p&gt;
Special thanks go to Dan Peori (&lt;a href=&quot;mailto:peori@oopo.net&quot;&gt;peori@oopo.net&lt;/a&gt;) for writing the pack and unpack programs which helped me to understand the structure of the PBP file format.
&lt;/p&gt;
&lt;p&gt;
Special thanks to Sebastian Henschel and Philippe Maes for the distribution files and support.
&lt;/p&gt;
&lt;h2&gt;License&lt;/h2&gt;
&lt;p&gt;
This program is distributed under the terms of the GPL v2. Please read the LICENSE file included in the distribution of the program for more information.
&lt;/p&gt;
&lt;p&gt;
This program comes with NO WARRANTY and is distributed AS IS, use it at your own risk. The author takes no responsability of the possible damage caused to your computer or your PSP.
&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;html&gt;
&lt;head&gt;
<byte value="x9"/>&lt;meta HTTP-EQUIV=&quot;CONTENT-TYPE&quot; CONTENT=&quot;text/html; charset=utf-8&quot;&gt;
<byte value="x9"/>&lt;title&gt;QPSPManager: Acerca de&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1 align=center&gt;QPSPManager&lt;/h1&gt;&lt;p align=center&gt;
El gestor de ficheros de PSP para Linux&lt;/p&gt;
&lt;p align=center&gt;
versión 1.2
&lt;/p&gt;
&lt;p align=center&gt;
(C) 2005 Bernat Ràfales Mulet
&lt;/p&gt;
&lt;p align=center&gt;
&lt;a href=&quot;http://qpspmanager.sourceforge.net&quot;&gt;http://qpspmanager.sourceforge.net&lt;/a&gt;
&lt;/p&gt;
&lt;h2&gt;Information&lt;/h2&gt;
&lt;p&gt;
QPSPManager es un gestor de ficheros de PSP para Linux. Está pensado para usarse como una GUI amigable que ayude al usuario en la tareas pesadas de empaquetar y desempaquetar los ficheros PBP de PSP, en la creación de directorios y posterior copia de los mismos en la PSP (para ser ejecutados en firmwares 1.50); y en proporcionar funcionalidades como la selección de iconos personalizados o en la inserción de fondos de pantalla en los menús. Además, también dispone de funcionalidades para realizar copias de seguridad de las partidas guardadas en tu ordenador.
&lt;/p&gt;
&lt;h2&gt;Autores&lt;/h2&gt;
&lt;p&gt;
Este programa ha sido diseñado y desarrollado por Bernat Ràfales Mulet.
&lt;h2&gt;Informar sobre errores / Feedback / Contactar con el autor&lt;/h2&gt;
&lt;p&gt;
Si deseas informar sobre errores, tienes sugerencias, o deseas realizar aportaciones, no te cortes, y contacta con el autor en &lt;a href=&quot;mailto:the_bell@users.sourceforge.net&quot;&gt;the_bell@users.sourceforge.net&lt;/a&gt;.
&lt;/p&gt;
&lt;p&gt;
No olvides visitar la Página Oficial en &lt;a href=&quot;http://qpspmanager.sourceforge.net&quot;&gt;http://qpspmanager.sourceforge.net&lt;/a&gt; para obtener las últimas actualizaciones y noticias sobre QPSPManager.
&lt;/p&gt;
&lt;h2&gt;Agradecimientos&lt;/h2&gt;
&lt;p&gt;
Agradecer a Dan Peori (&lt;a href=&quot;mailto:peori@oopo.net&quot;&gt;peori@oopo.net&lt;/a&gt;) sus utilidades para empaquetar y desempaquetar. Me sirvieron de mucha ayuda para entender la estructura y formato de los ficheros PBP.
&lt;/p&gt;
&lt;p&gt;
Agradecer a Sebastian Henschel y Philippe Maes los ficheros de distribución y el soporte prestado.
&lt;/p&gt;
&lt;h2&gt;Licencia&lt;/h2&gt;
&lt;p&gt;
Este programa se distribuye según las condiciones de la licencia GPL v2. Por favor, lee el fichero LICENSE que se incluye junto a la distribución del programa para disponer de más información.
&lt;/p&gt;
&lt;p&gt;
Este programa no tiene NINGUNA GARANTÍA y se distribuye TAL CUAL. Úsalo bajo tu propia responsabilidad. El autor no se hace responsable de los posibles daños que pueda causar a tu ordenador o a tu PSP.
&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
</context>
</TS>
