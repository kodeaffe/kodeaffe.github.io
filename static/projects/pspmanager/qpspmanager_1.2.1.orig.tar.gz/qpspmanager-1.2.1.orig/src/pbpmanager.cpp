/***************************************************************************
 *   Copyright (C) 2005 by Bernat Ràfales                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

//$Revision: 1.10 $

#include "pbpmanager.h"
#include "filemanager.h"
#include <qfile.h>
#include <qdatastream.h>
#include <qpixmap.h>
#include <qregexp.h>


PBPManager::PBPManager(PSPOptions *options)
{
    this->options = options;
}


PBPManager::~PBPManager()
{
}


int PBPManager::unpack(QString inputFile, QString outDir)
{
    QString files[8] =
    {
        "PARAM.SFO",
        "ICON0.PNG",
        "ICON1.PMF",
        "UNKNOWN.PNG",
        "PIC1.PNG",
        "SND0.AT3",
        "UNKNOWN.PSP",
        "UNKNOWN.PSAR"
    };

    int size;
    char *s;
    QFile inFile( inputFile );
    QFile *outFile;
    if (!(inFile.open( IO_ReadOnly )))
    {
        return -6; //Cannot open file for reading
    }
    QDataStream inStream( &inFile );
    QDataStream *outStream;
    
    //Signature
    char signature[4];
    inStream.readRawBytes((char *)(signature), sizeof(signature));
    qDebug(signature);

    if ((signature[0] != 0x00) || (signature[1] != 0x50) || (signature[2] != 0x42) || (signature[3] != 0x50))
    {
        return -7; //Not a PBP file
    }

    //Version
    unsigned int version;
    inStream >> version;

    //Files offset
    u_int32_t offset[9];
    inStream.readRawBytes((char *)(offset), sizeof(offset) - sizeof(u_int32_t));

    offset[8] = inFile.size();

    //For endianness problems
    for (int i = 0; i < 8; i++)
    {
        offset[i] = le32(offset[i]);
    }

    //Main bucle
    for (int i = 0; i < 8; i++)
    {
        outFile = new QFile(outDir + "/" + files[i]);
        size = (offset[i + 1] - offset[i]);
        if(!(outFile->open(IO_WriteOnly)))
        {
            return -8; //Error creating temp files
        }
        outStream = new QDataStream(outFile);
        s = (char *)(malloc(size));
        inStream.readRawBytes(s, size);
        outStream->writeRawBytes(s, size);
        outFile->close();
        free(s);
    }
    inFile.close();
    return 2;
}


//TODO: allow no icon, sound, movie and background files
//by passing an empty filename
int PBPManager::pack(QString outputFile, QString inFiles[7])
{
    QFile outFile(outputFile);
    if(!(outFile.open(IO_WriteOnly)))
    {
        return -1;
    }
    QDataStream outStream(&outFile);

    char signature[4] =
    {
        0x00,
        0x50,
        0x42,
        0x50
    };

    char version[4] =
    {
        0x00,
        0x00,
        0x01,
        0x00
    };

    u_int32_t offset[8];

    offset[0] = le32(40); //The size of the header

    //We will copy the data of the files in a buffer
    //and we will copy it later
    char *fileData[7];

    for (int i = 0; i < 7; i++)
    {
        if (inFiles[i] != "")
        {
            QFile inFile(inFiles[i]);
            if(!(inFile.open(IO_ReadOnly)))
            {
                return -2;
            }
            QDataStream inStream(&inFile);

            //Calculate offset
            if (i == 6) //ELF File, we eliminate it
            {
                offset[i+1] = le32(offset[i]);
            }
            else
            {
                offset[i+1] = le32(offset[i] + inFile.size());
            }
            //Copy data to buffer
            fileData[i] = (char *)(malloc(inFile.size()));
            inStream.readRawBytes(fileData[i], inFile.size());
            inFile.close();
        }
        else //Set the offset to 0 bytes and set a null pointer
        {
            offset[i+1] = le32(offset[i]);
            fileData[i] = 0;
        }
    }

    //Now we begin writing to the file
    //The header
    outStream.writeRawBytes((char *)(signature), sizeof(signature));
    outStream.writeRawBytes((char *)(version), sizeof(version));
    outStream.writeRawBytes((char *)(offset), sizeof(offset));

    //The files to pack, already copied in a buffer array
    for(int i = 0; i < 7; i++)
    {
        outStream.writeRawBytes(fileData[i], offset[i + 1] - offset[i]);
        free(fileData[i]);
    }

    outFile.close();

    return 0;
}

//TODO: check is a valid PBP file
QString PBPManager::programName(QString filename)
{
    QFile file(filename);
    if(!(file.open(IO_ReadOnly)))
    {
        return "";
    }
    QDataStream stream(&file);

    Q_UINT8 signature[4];
    //Signature
    for (int i = 0; i < 4; i++)
    {
        stream >> signature[i];
    }

    //Version
    Q_UINT32 version;
    stream >> version;

    //Files offset
    Q_UINT32 offset[8];
    for (int i = 0; i < 8; i++)
    {
        stream >> offset[i];
    }

    //PARAM.SFO
    char *s = (char *)(malloc(256));
    stream.readRawBytes(s, 256);
    QString title = "";
    int i = 128;
    bool end = (s[i] == 0x00);

    while (!end)
    {
        title += s[i];
        i++;
        end = (s[i] == 0x00);
    }

    free(s);
    return title;
}


bool PBPManager::copyFolder(QString inputDir, QString outputDir, QString PBPFile)
{
    QDir inDir(inputDir);
    QDir outDir(outputDir);
    QFileInfoList dirList(*(inDir.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoSymLinks)));

    //Delete . and .. dirs, and the PBP file
    dirList.removeFirst();
    dirList.removeFirst();
    QFileInfo *file = dirList.first();
    while((file->isDir()) || (file->fileName() != PBPFile))
    {
        file = dirList.next();
    }

    dirList.remove();

    return fileManager::copyFiles(outDir, dirList);
}


bool PBPManager::copyPBP(QString inFile, QString outFile)
{
    return fileManager::copyFile(inFile, outFile);
}


bool PBPManager::checkBackground(QString filename)
{
    QFile file(filename);
    if (file.size() == 0) //Empty background considered valid
    {
        return true;
    }
    QPixmap background(filename);
    //TODO: check bpp, the depth() method returns 24 even if the png file is 32 bpp
    if (!background.isNull() && background.width() == 480 && background.height() == 272)
    {
        return true;
    }
    return false;
}


bool PBPManager::checkIcon(QString filename)
{
    QFile file(filename);
    if (file.size() == 0) //Empty icon considered valid
    {
        return true;
    }
    QPixmap background(filename);
    //TODO: check bpp, the depth() method returns 24 even if the png file is 32 bpp
    if (!background.isNull())
    {
        return true;
    }
    return false;
}

//We consider empty files as good ones
bool PBPManager::checkPMF(QString filename)
{
    QFile file(filename);
    if (file.size() == 0)
    {
        return true;
    }
    else
    {
        file.open(IO_ReadOnly);
        QDataStream inStream(&file);
        char signature[8];
        inStream.readRawBytes((char *)signature, sizeof(signature));
        return ((signature[0] == 'P') && (signature[1] == 'S') && (signature[2] == 'M') && (signature[3] == 'F') && (signature[4] == '0') && (signature[5] == '0') && (signature[6] == '1') && (signature[7] == '2'));
    }
}


bool PBPManager::checkAT3(QString filename)
{
    QFile file(filename);
    if (file.size() == 0)
    {
        return true;
    }
    else
    {
        file.open(IO_ReadOnly);
        QDataStream inStream(&file);
        char signature[4];
        inStream.readRawBytes((char *)signature, sizeof(signature));
        return ((signature[0] == 'R') && (signature[1] == 'I') && (signature[2] == 'F') && (signature[3] == 'F'));
    }
}


int PBPManager::transferFiles()
{
    //We should check that everything setting is 
    //set and correct, and if everything is ok we
    //proceed to pack the files to generate the
    //reduced PBP file and then we transfer it and
    //all auxiliary files of the directory where the
    //original PBP fie is located to the output + programName
    //directory. Note that in further versions we
    //will add support for selecting which files and
    //directories we want to transfer

    //1 - check all files to pack the reduced PBP file exists
    //3 - check that we have write access to outputDir
    //4 - create outputDir + programName
    //5 - pack the reduced PBP file into the (4) directory
    //6 - copy all files from the original PBP file to (4) directory

    //(1)
    QString icon;
    QString background;
    QString PMF;
    QString AT3;

    if (options->getWantIcon())
    {
        icon = options->getIconFile();
    }
    else
    {
        icon = "";
    }

    if (options->getWantBackground())
    {
        background = options->getBackgroundFile();
    }
    else
    {
        background = "";
    }

    if (options->getWantMovie())
    {
        PMF = options->getPMFFile();
    }
    else
    {
        PMF = "";
    }

    if (options->getWantSound())
    {
        AT3 = options->getAT3File();
    }
    else
    {
        AT3 = "";
    }

    QString files[7] = 
    {
        (options->getTempDir() + "PARAM.SFO"),
        (icon),
        (PMF),
        (options->getTempDir() + "UNKNOWN.PNG"),
        (background),
        (AT3),
        (options->getTempDir() + "UNKNOWN.PSAR") 
    };

    for(int i = 0; i < 7; i++)
    {
        if (files[i] != "" && !QFile::exists(files[i]))
        {
            return -1; //Files problem
        }
    }

    //(3) and (4)
    //TODO: if the directories already exist ask the user to delete
    //its on the transfer and do so

    QString directoryStripped;
    QString directoryNonStripped;
    QDir directory;
    if (!(options->getHideDamage()))
    {
        directoryStripped = options->getOutputDir() + options->getProgramName() + "%";
        directoryNonStripped = options->getOutputDir() + options->getProgramName();
    }
    else
    {
        //The directory non stripped must be 32 chars long and must and with a '1'
        //we check the program name and stuff extra '_'
        //The stripped directory must be 9 chars lenght and must end in
        //the sequence "~1%"

        directoryStripped = getDirectoryStripped(options->getProgramName());
        directoryNonStripped = getDirectoryNonStripped(options->getProgramName());

    if (directory.exists(directoryNonStripped) || directory.exists(directoryStripped))
    {
        return -2; //Files not transferred by user decision
    }
    else
    {
        if (!(directory.mkdir(directoryNonStripped)))
        {
            return -3; //Error creating directories
        }
        if (!(directory.mkdir(directoryStripped)))
        {
            return -3;
        }
    }
}

    //(5)
    //Call the pack routine with the right files

    int result = pack(directoryStripped + "/EBOOT.PBP", files);
    if (result != 0)
    {
        return -4; //Error packing 
    }

    //6
    //Simple implementation of a cp -R source dest
    //Added support for remove the original PBP file
    //which is not needed

    QString sourceDirectory = QFileInfo(options->getFileName()).dirPath();

    if (copyFolder(sourceDirectory, directoryNonStripped, QFileInfo(options->getFileName()).fileName()) != 1)
    {
        return -5; //Error copying files
    }
    
    //We copy the real PBP File (ELF only)
    //Copy
    if((copyPBP(options->getTempDir() + "UNKNOWN.PSP", directoryNonStripped + "/EBOOT.PBP")) != 1)
    {
        return -5;
    }
    else
    {
        return 1; //Files transferred ok
    }
}


//TODO: check filesystem restrictions
bool PBPManager::checkProgramName(QString name)
{
    return (!name.isEmpty());
}


QString PBPManager::validDirectory(QString name)
{
    //Only accept letters, numbers and '_' characters
    //and 30 chars long
    QString newName = name.replace(QRegExp("[^\\w]"), "");
    newName.truncate(30);
    return newName;;
}


QString PBPManager::getMessage(int i)
{
    switch (i)
    {
        case 1:
            return QObject::tr("Files were correctly transferred.");
        case 2:
            return QObject::tr("PBP file unpacked successfully.");
        case 3:
            return QObject::tr("Directories successfully created. Now you can copy them to your PSP");
        case -1:
            return QObject::tr("Necessary files not found. Open the PBP file again.");
        case -2:
            return QObject::tr("Directory already exists. Delete it first.");
        case -3:
            return QObject::tr("Error creating directories, check permissions in the PSP directory.");
        case -4:
            return QObject::tr("Error packing the files. Check the files and try again.");
        case -5:
            return QObject::tr("Error copying files.");
        case -6:
            return QObject::tr("Error opening the PBP file for reading.");
        case -7:
            return QObject::tr("The file selected is not a PBP file.");
        case -8:
            return QObject::tr("Error creating temporary files. Check permissions on the temp directory.");
        case -9:
            return QObject::tr("Could not find the \"pair\" directory. Please check both directories are in the same place.");
        default:
            return QObject::tr("Unknown error.");
    }
}


//Copyright Chris Barrera a.k.a. Gorim
u_int32_t PBPManager::le32(u_int32_t bits)
{
    u_int8_t *bytes;
    bytes = (u_int8_t*)&bits;
    return(bytes[0] | (bytes[1]<<8) | (bytes[2]<<16) | (bytes[3]<<24));
}


QString PBPManager::getDirectoryStripped(QString directory)
{
        int nameLength = directory.length();
        QString directoryStripped = options->getOutputDir();

        if (nameLength >= 6)
        {
            for (int i = 0; i < 6; i++)
            {
                directoryStripped += (directory)[i];
            }
        }
        else
        {
            directoryStripped += directory;
            for (unsigned int i = 0; i < (6 - directory.length()); i++)
            {
                directoryStripped += "_";
            }
        }

        directoryStripped += "~1%";

        return directoryStripped;
}


QString PBPManager::getDirectoryNonStripped(QString directory)
{
       int nameLength = directory.length();
       QString directoryNonStripped = options->getOutputDir() + directory;
       for (int i = 0; i < 32 - nameLength - 1; i++)
       {
           directoryNonStripped += "_";
       }

       directoryNonStripped += "1";

       return directoryNonStripped;
}


//Copies and renames directories with kxploit applied without
//having damaged the data
int PBPManager::hideDamage(QString directory)
{
    QDir auxDir;
    directory.truncate(directory.length() - 1);
    QString originalStrippedDirectory;
    QString originalNonStrippedDirectory;
    QString strippedDirectory;
    QString nonStrippedDirectory;

    //First we check if the user has selected the elf or the pbp directory
    if (isStrippedDirectory(directory))
    {
        originalStrippedDirectory = directory;
        originalNonStrippedDirectory = directory;
        originalNonStrippedDirectory.truncate(directory.length() - 1);
    }
    else
    {
        originalStrippedDirectory = directory + "%";
        originalNonStrippedDirectory = directory;
    }

    //Check both directories exist
    if (!auxDir.exists(originalStrippedDirectory) || !auxDir.exists(originalNonStrippedDirectory))
    {
        return -9;
    }

    //Now we define the correct "hidden damage" directories on the PSP

    strippedDirectory = directory.section('/', 0, -2) + "/" + getDirectoryStripped(originalNonStrippedDirectory.section('/', -1, -1)).section('/', -1, -1);
    nonStrippedDirectory = directory.section('/', 0, -2) + "/" + getDirectoryNonStripped(originalNonStrippedDirectory.section('/', -1, -1)).section('/', -1, -1);


    //Now we simply have to copy the original folders to the new renamed directory
    //on the PSP

    if ((auxDir.exists(strippedDirectory)) || (auxDir.exists(nonStrippedDirectory)))
    {
        return -2;
    }
    if (fileManager::copyFolder(QDir(originalNonStrippedDirectory), QDir(nonStrippedDirectory)) && 
        fileManager::copyFolder(QDir(originalStrippedDirectory), QDir(strippedDirectory)))
    {
        return 3;
    }
    else
    {
        return -5;
    }

}

bool PBPManager::isStrippedDirectory(QString directory)
{
    //We could do it better by looking into the dir and 
    //analysing the eboot.pbp file, but this is simpler
    //and it should work on most cases
    return (directory[directory.length() - 1] == '%');
}
