<!DOCTYPE TS><TS>
<context>
    <name>QObject</name>
    <message>
        <source>Files were correctly transferred.</source>
        <translation>Els arxius s&apos;han transferit correctament.</translation>
    </message>
    <message>
        <source>PBP file unpacked successfully.</source>
        <translation>Arxiu PBP desenpaquetat correctament.</translation>
    </message>
    <message>
        <source>Directories successfully created. Now you can copy them to your PSP</source>
        <translation>Directoris creats correctament. Ja pots copiar-los a la teva PSP</translation>
    </message>
    <message>
        <source>Necessary files not found. Open the PBP file again.</source>
        <translation>No s&apos;han trobat els arxius necessaris. Caldrà obrir un altre cop l&apos;arxiu PBP.</translation>
    </message>
    <message>
        <source>Directory already exists. Delete it first.</source>
        <translation>La carpeta ja existeix. Esborra-la primer.</translation>
    </message>
    <message>
        <source>Error creating directories, check permissions in the PSP directory.</source>
        <translation>S&apos;ha produït un error al crear la carpeta. Revisa els permisos del directori de la PSP.</translation>
    </message>
    <message>
        <source>Error packing the files. Check the files and try again.</source>
        <translation>Error al empaquetar els arxius. Revisa&apos;ls i torna-ho a intentar.</translation>
    </message>
    <message>
        <source>Error copying files.</source>
        <translation>Error al copiar els arxius.</translation>
    </message>
    <message>
        <source>Error opening the PBP file for reading.</source>
        <translation>Error al obrir l&apos;arxiu PBP per lectura.</translation>
    </message>
    <message>
        <source>The file selected is not a PBP file.</source>
        <translation>L&apos;arxiu sel·lecionat no és un arxiu PBP.</translation>
    </message>
    <message>
        <source>Error creating temporary files. Check permissions on the temp directory.</source>
        <translation>Error al crear l&apos;arxiu temporal. Revisa  els permisos del directori temporal.</translation>
    </message>
    <message>
        <source>Could not find the &quot;pair&quot; directory. Please check both directories are in the same place.</source>
        <translation>No es pot trobar la parella de directoris. Siusplau, comproba que els dos directoris estan junts.</translation>
    </message>
    <message>
        <source>Unknown error.</source>
        <translation>Error desconegut.</translation>
    </message>
    <message>
        <source>Destination files already exists. Do you want to overwrite them?</source>
        <translation>Els arxius destí ja existeixen. Vols sobreescriure&apos;ls?</translation>
    </message>
    <message>
        <source>You are going to overwrite
</source>
        <translation>Sobreescriuràs l&apos;arxiu
</translation>
    </message>
    <message>
        <source> from </source>
        <translation> de </translation>
    </message>
    <message>
        <source>
over another one from </source>
        <translation>
per aquest altre </translation>
    </message>
    <message>
        <source>
Are you sure you want to proceed?</source>
        <translation>
Segur que vols continuar?</translation>
    </message>
    <message>
        <source>Error transferring savegame</source>
        <translation>Error al copiar la partida desada</translation>
    </message>
    <message>
        <source>Error deleting savegame</source>
        <translation>Error borrant la partida desada</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the </source>
        <translation>Segur que vols esborrar la</translation>
    </message>
    <message>
        <source> savegame?</source>
        <translation> partida desada?</translation>
    </message>
</context>
<context>
    <name>mainWindow</name>
    <message>
        <source>QPSPManager</source>
        <translation>QPSPManager</translation>
    </message>
    <message>
        <source>PBP File</source>
        <translation>Arxiu PBP</translation>
    </message>
    <message>
        <source>AT3 file</source>
        <translation>Arxiu AT3</translation>
    </message>
    <message>
        <source>Open an AT3 file</source>
        <translation>Tria l&apos;arxiu AT3</translation>
    </message>
    <message>
        <source>PBP file</source>
        <translation>Arxiu PBP</translation>
    </message>
    <message>
        <source>Open a PBP file</source>
        <translation>Tria l&apos;arxiu PBP</translation>
    </message>
    <message>
        <source>PMF file</source>
        <translation>Arxiu PMF</translation>
    </message>
    <message>
        <source>Open a PMF file</source>
        <translation>Tria l&apos;arxiu PMF</translation>
    </message>
    <message>
        <source>Icon file</source>
        <translation>Icona</translation>
    </message>
    <message>
        <source>Icon File</source>
        <translation>Icona</translation>
    </message>
    <message>
        <source>Select an icon file</source>
        <translation>Tria l&apos;icona</translation>
    </message>
    <message>
        <source>Background file</source>
        <translation>Arxiu de fons</translation>
    </message>
    <message>
        <source>Background File</source>
        <translation>Arxiu de fons</translation>
    </message>
    <message>
        <source>Select a background file</source>
        <translation>Tria un arxiu de fons</translation>
    </message>
    <message>
        <source>Program Name:</source>
        <translation>Nom del programa:</translation>
    </message>
    <message>
        <source>Write the program name here</source>
        <translation>Escriu el nom del programa aquí</translation>
    </message>
    <message>
        <source>Transfer files to PSP</source>
        <translation>Copiar els arxius a la PSP</translation>
    </message>
    <message>
        <source>Transfer the files</source>
        <translation>Copiar els arxius</translation>
    </message>
    <message>
        <source>Hide damage of an existing directory</source>
        <translation>Ocultar les dades malmeses d&apos;un directori existent</translation>
    </message>
    <message>
        <source>Savegames</source>
        <translation>Partides desades</translation>
    </message>
    <message>
        <source>Computer</source>
        <translation>Ordinador</translation>
    </message>
    <message>
        <source>New Item</source>
        <translation>Nou element</translation>
    </message>
    <message>
        <source>Delete savegames from Computer</source>
        <translation>Esborrar les partides desades de l&apos;ordinador</translation>
    </message>
    <message>
        <source>Transfer selected savegames to PSP</source>
        <translation>Copiar les partides selecionades a la PSP</translation>
    </message>
    <message>
        <source>Transfer selected savegames to Computer</source>
        <translation>Copiar les partides seleccionades a l&apos;ordinador</translation>
    </message>
    <message>
        <source>Transfer all savegames to PSP</source>
        <translation>Copiar totes les partides desades a la PSP</translation>
    </message>
    <message>
        <source>Transfer all savegames to Computer</source>
        <translation>Copiar totes les partides desades a l&apos;ordinador</translation>
    </message>
    <message>
        <source>PSP</source>
        <translation>PSP</translation>
    </message>
    <message>
        <source>Delete savegames from PSP</source>
        <translation>Esborrar les partides desades de la PSP</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opcions</translation>
    </message>
    <message>
        <source>PSP Directory:</source>
        <translation>Directori de la PSP:</translation>
    </message>
    <message>
        <source>Select the root PSP directory</source>
        <translation>Selecciona el directori arrel de la PSP</translation>
    </message>
    <message>
        <source>Check</source>
        <translation>Comprova</translation>
    </message>
    <message>
        <source>Check if the current PSP directory is correct</source>
        <translation>Comprova si el directori actual de la PSP es correcte</translation>
    </message>
    <message>
        <source>Hide PBP damaged files</source>
        <translation>Amaga les dades malmeses</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <source>Hide the damaged data in the PSP</source>
        <translation>Amaga les dades malmeses de la PSP</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Do not hide the damaged data in the PSP</source>
        <translation>No amaguis les dades malmeses de la PSP</translation>
    </message>
    <message>
        <source>Ask deleting/overwriting savegames</source>
        <translation>Pregunta&apos;m abans d&apos;esborrar o sobreescriure les partides desades</translation>
    </message>
    <message>
        <source>Save Preferences</source>
        <translation>Desa la configuració</translation>
    </message>
    <message>
        <source>Save the options for further uses</source>
        <translation>Desa les opcions per a usos posteriors</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>Quant a...</translation>
    </message>
    <message>
        <source>PBP Files</source>
        <translation>Arxius PBP</translation>
    </message>
    <message>
        <source>open file dialog</source>
        <translation>Finestra d&apos;obrir arxiu</translation>
    </message>
    <message>
        <source>Choose a PSP executable</source>
        <translation>Tria un executable de la PSP</translation>
    </message>
    <message>
        <source>Choose an icon file</source>
        <translation>Tria una icona</translation>
    </message>
    <message>
        <source>Choose a background file</source>
        <translation>Tria un arxiu de fons</translation>
    </message>
    <message>
        <source>get existing directory</source>
        <translation>Obte un directori existent</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Tria un directori</translation>
    </message>
    <message>
        <source>Choose a PMF file</source>
        <translation>Tria un arxiu PMF</translation>
    </message>
    <message>
        <source>Choose an AT3 file</source>
        <translation>Tria un arxiu AT3</translation>
    </message>
    <message>
        <source>Your PSP is too fresh. There is no hack to put homebrew software on your device, yet.
Section PBP File was disabled!</source>
        <translation>Tens una PSP massa nova. No s&apos;ha descobert cap forma de carregar programari casolà a la teva PSP, de moment.
Totes les opcions de PBP s&apos;han desactivat!</translation>
    </message>
    <message>
        <source>Choose the directory</source>
        <translation>Tria una carpeta</translation>
    </message>
    <message>
        <source>Some options are not correctly set</source>
        <translation>Algunes opcions no estan ben configurades</translation>
    </message>
    <message>
        <source>You must open a PBP file before transfering files</source>
        <translation>Necessites obrir un fitxer PBP abans de transferir els arxius</translation>
    </message>
    <message>
        <source>You must set the PSP directory before transfering files</source>
        <translation>Necessites configurar el directori de la PSP abans de copiar els arxius</translation>
    </message>
    <message>
        <source>Files will be transferred to </source>
        <translation>Els arxius es copiaran a </translation>
    </message>
    <message>
        <source>The program name is not valid</source>
        <translation>El nom del programa no és vàlid</translation>
    </message>
    <message>
        <source>Invalid background image. Check is 480x272 in size</source>
        <translation>La imatge de fons ha de tindre una mida de 480x272</translation>
    </message>
    <message>
        <source>Invalid PMF file</source>
        <translation>Arxiu PMF incorrecte</translation>
    </message>
    <message>
        <source>Invalid AT3 file</source>
        <translation>L&apos;arxiu AT3 no es correcte</translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>windowAbout</name>
    <message>
        <source>About/Help</source>
        <translation>Quant  a</translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;html&gt;
&lt;head&gt;
<byte value="x9"/>&lt;meta HTTP-EQUIV=&quot;CONTENT-TYPE&quot; CONTENT=&quot;text/html; charset=utf-8&quot;&gt;
<byte value="x9"/>&lt;title&gt;QPSPManager: About&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1 align=center&gt;QPSPManager&lt;/h1&gt;&lt;p align=center&gt;
The Linux PSP File Manager&lt;/p&gt;
&lt;p align=center&gt;
version 1.2
&lt;/p&gt;
&lt;p align=center&gt;
(C) 2005 Bernat Ràfales Mulet
&lt;/p&gt;
&lt;p align=center&gt;
&lt;a href=&quot;http://qpspmanager.sourceforge.net&quot;&gt;http://qpspmanager.sourceforge.net&lt;/a&gt;
&lt;/p&gt;
&lt;h2&gt;Information&lt;/h2&gt;
&lt;p&gt;
QPSPManager is a PSP File manager for Linux. It&apos;s intended to use as a user friendly GUI to the known tedious pack and unpack processes of the PSP PBP files, directory generation and further copy into the PSP in order to execute those files in firmwares 1.50, providing some other features as selecting a custom icon or background file to show on the menu. It also provides support for backuping savegames on the computer.
&lt;/p&gt;
&lt;h2&gt;Authors&lt;/h2&gt;
&lt;p&gt;
This program was designed and developed by Bernat Ràfales Mulet.
&lt;h2&gt;Report bugs / Feedback / Contact author&lt;/h2&gt;
&lt;p&gt;
Please feel free to report bugs, feedbacks or suggestions to the author at &lt;a href=&quot;mailto:the_bell@users.sourceforge.net&quot;&gt;the_bell@users.sourceforge.net&lt;/a&gt;.
&lt;/p&gt;
&lt;p&gt;
Don&apos;t forget to visit the Official home page at &lt;a href=&quot;http://qpspmanager.sourceforge.net&quot;&gt;http://qpspmanager.sourceforge.net&lt;/a&gt; for updates or news about QPSPManager.
&lt;/p&gt;
&lt;h2&gt;Special thanks&lt;/h2&gt;
&lt;p&gt;
Special thanks go to Dan Peori (&lt;a href=&quot;mailto:peori@oopo.net&quot;&gt;peori@oopo.net&lt;/a&gt;) for writing the pack and unpack programs which helped me to understand the structure of the PBP file format.
&lt;/p&gt;
&lt;p&gt;
Special thanks to Sebastian Henschel and Philippe Maes for the distribution files and support.
&lt;/p&gt;
&lt;h2&gt;License&lt;/h2&gt;
&lt;p&gt;
This program is distributed under the terms of the GPL v2. Please read the LICENSE file included in the distribution of the program for more information.
&lt;/p&gt;
&lt;p&gt;
This program comes with NO WARRANTY and is distributed AS IS, use it at your own risk. The author takes no responsability of the possible damage caused to your computer or your PSP.
&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
