/***************************************************************************
 *   Copyright (C) 2005 by Bernat Ràfales                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

//$Revision: 1.3 $

#include "pspoptions.h"

PSPOptions::PSPOptions()
{
    QSettings settings;
    settingsSet = TRUE;
    //Check if there are options in the current system. If not we initialize them
    //to default values which should be checked afterwards
    bool ok = TRUE;
    settings.setPath( "qpspmanager.sourceforge.net", "QPSPManager" );
    hideDamage = settings.readBoolEntry("/PBP/hideDamage", TRUE, &ok);
    settingsSet = settingsSet && ok;
    overwriteSavegames = settings.readBoolEntry("/Savegames/overwriteSavegames", TRUE, &ok);
    settingsSet = settingsSet && ok;
    PSPDir = settings.readEntry("/General/PSPDir", "", &ok);
    settingsSet = settingsSet && ok;
    wantIcon = TRUE;
    wantBackground = TRUE;
    wantSound = TRUE;
    wantMovie = TRUE;
}


PSPOptions::~PSPOptions()
{
}


void PSPOptions::setOutputDir(QString dir)
{
    outputDir = dir;
}


QString PSPOptions::getOutputDir()
{
    return outputDir;
}


void PSPOptions::setSavegameDir(QString dir)
{
    savegameDir = dir;
}


QString PSPOptions::getSavegameDir()
{
    return savegameDir;
}


void PSPOptions::setSettingsSet(bool set)
{
    settingsSet = set;
}


bool PSPOptions::getSettingsSet()
{
    return settingsSet;
}


void PSPOptions::setHideDamage(bool hide)
{
    hideDamage = hide;
}


bool PSPOptions::getHideDamage()
{
    return hideDamage;
}


void PSPOptions::setPSPDir(QString dir)
{
    PSPDir = dir;
}


QString PSPOptions::getPSPDir()
{
    return PSPDir;
}


void PSPOptions::setTempDir(QString dir)
{
    tempDir = dir;
}


QString PSPOptions::getTempDir()
{
    return tempDir;
}


void PSPOptions::setFileName(QString file)
{
    fileName = file;
}


QString PSPOptions::getFileName()
{
    return fileName;
}


void PSPOptions::setIconFile(QString file)
{
    iconFile = file;
}


QString PSPOptions::getIconFile()
{
    return iconFile;
}


void PSPOptions::setBackgroundFile(QString file)
{
    backgroundFile = file;
}


QString PSPOptions::getBackgroundFile()
{
    return backgroundFile;
}


void PSPOptions::setOutputDirOK(bool ok)
{
    outputDirOK = ok;
}


void PSPOptions::setPSPDirOK(bool ok)
{
    PSPDirOK = ok;
}


void PSPOptions::setPSPDeviceOK(bool ok)
{
    PSPDeviceOK = ok;
}


//TODO: check all directories exists
bool PSPOptions::checkPSPDir()
{
    return (checkDir(PSPDir) && checkDir(PSPDir + "psp/savedata"));
}


bool PSPOptions::checkFile(QString fileName)
{
    return QFile::exists(fileName);
}


bool PSPOptions::checkDir(QString dir)
{
    QDir directory;
    return directory.exists(dir);
}


void PSPOptions::setProgramName(QString name)
{
    programName = name;
}


QString PSPOptions::getProgramName()
{
    return programName;
}


 void PSPOptions::setWantIcon(bool icon)
{
    wantIcon = icon;
}



 bool PSPOptions::getWantIcon()
{
    return wantIcon;
}



 void PSPOptions::setWantBackground(bool background)
{
    wantBackground = background;
}



 bool PSPOptions::getWantBackground()
{
    return wantBackground;
}



 void PSPOptions::setWantSound(bool sound)
{
    wantSound = sound;
}



 bool PSPOptions::getWantSound()
{
    return wantSound;
}



 void PSPOptions::setWantMovie(bool movie)
{
    wantMovie = movie;
}



 bool PSPOptions::getWantMovie()
{
    return wantMovie;
}


void PSPOptions::setOverwriteSavegames(bool overwrite)
{
    overwriteSavegames = overwrite;
}



 bool PSPOptions::getOverwriteSavegames()
{
    return overwriteSavegames;;
}


void PSPOptions::savePreferences()
{
    QSettings settings;
    settings.setPath( "qpspmanager.sourceforge.net", "QPSPManager" );
    settings.writeEntry("/PBP/hideDamage", hideDamage);
    settings.writeEntry("/Savegames/overwriteSavegames", overwriteSavegames);
    settings.writeEntry("/General/PSPDir", PSPDir);
}


void PSPOptions::setPMFFile(QString file)
{
    PMFFile = file;
}


QString PSPOptions::getPMFFile()
{
    return PMFFile;
}


void PSPOptions::setAT3File(QString file)
{
    AT3File = file;
}


QString PSPOptions::getAT3File()
{
    return AT3File;
}
