<!DOCTYPE TS><TS>
<context>
    <name>QObject</name>
    <message>
        <source>Files were correctly transferred.</source>
        <translation>I files sono stati trasferiti con successo.</translation>
    </message>
    <message>
        <source>PBP file unpacked successfully.</source>
        <translation>File PBP estratto con successo.</translation>
    </message>
    <message>
        <source>Directories successfully created. Now you can copy them to your PSP</source>
        <translation>Le cartelle sono state create con successo, potete copiarle sulla vostra PSP</translation>
    </message>
    <message>
        <source>Necessary files not found. Open the PBP file again.</source>
        <translation>Non ho trovato i files necessari, apri il .pbp di nuovo.</translation>
    </message>
    <message>
        <source>Directory already exists. Delete it first.</source>
        <translation>La cartella esiste gi? ?necessario cancellarla prima di proseguire.</translation>
    </message>
    <message>
        <source>Error creating directories, check permissions in the PSP directory.</source>
        <translation>Si ?verificato un errore nel creare le cartelle,controlla i permessi sulla cartella PSP.</translation>
    </message>
    <message>
        <source>Error packing the files. Check the files and try again.</source>
        <translation>Errore nel riunire i files, controllali e prova di nuovo.</translation>
    </message>
    <message>
        <source>Error copying files.</source>
        <translation>Errore nella copiatura dei files.</translation>
    </message>
    <message>
        <source>Error opening the PBP file for reading.</source>
        <translation>Si ?verificato un errore nell&apos;apertura del file PBP (modalit?di lettura).</translation>
    </message>
    <message>
        <source>The file selected is not a PBP file.</source>
        <translation>Il file selezionato non ?di tipo PBP.</translation>
    </message>
    <message>
        <source>Error creating temporary files. Check permissions on the temp directory.</source>
        <translation>Si ?verificato un errore nel creare i files temporanei, controlla i permessi sulla cartella temp.</translation>
    </message>
    <message>
        <source>Could not find the &quot;pair&quot; directory. Please check both directories are in the same place.</source>
        <translation>Non riesco a trovare la cartella &quot;pair&quot;. Controlla che entrambe le cartelle siano nello stesso posto.</translation>
    </message>
    <message>
        <source>Unknown error.</source>
        <translation>Errore sconosciuto.</translation>
    </message>
    <message>
        <source>Destination files already exists. Do you want to overwrite them?</source>
        <translation>Files di destinazione gi?presenti, vuoi sovrascriverli?</translation>
    </message>
    <message>
        <source>You are going to overwrite
</source>
        <translation>Stai per sovrascrivere
</translation>
    </message>
    <message>
        <source> from </source>
        <translation type="unfinished"> from</translation>
    </message>
    <message>
        <source>
over another one from </source>
        <translation type="unfinished">
over another one from </translation>
    </message>
    <message>
        <source>
Are you sure you want to proceed?</source>
        <translation>
Sei sicuro di voler continuare?</translation>
    </message>
    <message>
        <source>Error transferring savegame</source>
        <translation>Errore nel trasferimento dei files di salvataggio</translation>
    </message>
    <message>
        <source>Error deleting savegame</source>
        <translation>Errore cancellazione dei files di salvataggio</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the </source>
        <translation>Sei sicuro di voler cancellare il </translation>
    </message>
    <message>
        <source> savegame?</source>
        <translation> salvataggio? </translation>
    </message>
</context>
<context>
    <name>mainWindow</name>
    <message>
        <source>QPSPManager</source>
        <translation>QPSPManager</translation>
    </message>
    <message>
        <source>PBP File</source>
        <translation>Arxiu PBP</translation>
    </message>
    <message>
        <source>AT3 file</source>
        <translation>Arxiu AT3</translation>
    </message>
    <message>
        <source>Open an AT3 file</source>
        <translation>Apri AT3 file</translation>
    </message>
    <message>
        <source>PBP file</source>
        <translation>Arxiu PBP</translation>
    </message>
    <message>
        <source>Open a PBP file</source>
        <translation>Apri PBP file</translation>
    </message>
    <message>
        <source>PMF file</source>
        <translation>Arxiu PMF</translation>
    </message>
    <message>
        <source>Open a PMF file</source>
        <translation>Apri PMF file</translation>
    </message>
    <message>
        <source>Icon file</source>
        <translation>Icona del file</translation>
    </message>
    <message>
        <source>Icon File</source>
        <translation>Icona del file</translation>
    </message>
    <message>
        <source>Select an icon file</source>
        <translation>Seleziona un file icona</translation>
    </message>
    <message>
        <source>Background file</source>
        <translation>File di background</translation>
    </message>
    <message>
        <source>Background File</source>
        <translation>File di background</translation>
    </message>
    <message>
        <source>Select a background file</source>
        <translation>Seleziona un file di background</translation>
    </message>
    <message>
        <source>Program Name:</source>
        <translation>Nome del programma:</translation>
    </message>
    <message>
        <source>Write the program name here</source>
        <translation>Scrivi qui il nome del programma</translation>
    </message>
    <message>
        <source>Transfer files to PSP</source>
        <translation>Trasferisci i files su PSP</translation>
    </message>
    <message>
        <source>Transfer the files</source>
        <translation>Trasferisci i files</translation>
    </message>
    <message>
        <source>Hide damage of an existing directory</source>
        <translation>Nascondi dati danneggiati</translation>
    </message>
    <message>
        <source>Savegames</source>
        <translation>Salvataggi</translation>
    </message>
    <message>
        <source>Computer</source>
        <translation>Computer</translation>
    </message>
    <message>
        <source>New Item</source>
        <translation>Nuovo oggetto</translation>
    </message>
    <message>
        <source>Delete savegames from Computer</source>
        <translation>Cancella salvataggi dal computer</translation>
    </message>
    <message>
        <source>Transfer selected savegames to PSP</source>
        <translation>Trasferisci salvataggi su PSP</translation>
    </message>
    <message>
        <source>Transfer selected savegames to Computer</source>
        <translation>Trasferisci i salvataggi selezionati sul pc</translation>
    </message>
    <message>
        <source>Transfer all savegames to PSP</source>
        <translation>Trasferisci tutti i salvataggi su PSP</translation>
    </message>
    <message>
        <source>Transfer all savegames to Computer</source>
        <translation>Trasferisci tutti i salvataggi sul pc</translation>
    </message>
    <message>
        <source>PSP</source>
        <translation>PSP</translation>
    </message>
    <message>
        <source>Delete savegames from PSP</source>
        <translation>Cancella i salvataggi da PSP</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opzioni</translation>
    </message>
    <message>
        <source>PSP Directory:</source>
        <translation>Cartella PSP:</translation>
    </message>
    <message>
        <source>Select the root PSP directory</source>
        <translation>Seleziona la cartella di base della PSP</translation>
    </message>
    <message>
        <source>Check</source>
        <translation>Controlla</translation>
    </message>
    <message>
        <source>Check if the current PSP directory is correct</source>
        <translation> Controlla se l&apos;attuale cartella PSP ?corretta</translation>
    </message>
    <message>
        <source>Hide PBP damaged files</source>
        <translation>Nascondi i files corrotti</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <source>Hide the damaged data in the PSP</source>
        <translation>Nascondi i dati danneggiati su PSP</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Do not hide the damaged data in the PSP</source>
        <translation>Non nascondere i files danneggati sulla PSP</translation>
    </message>
    <message>
        <source>Ask deleting/overwriting savegames</source>
        <translation>Chiedi per la cancellazione/sovrascrittura dei salvataggi</translation>
    </message>
    <message>
        <source>Save Preferences</source>
        <translation>Chiedi per la cancellazione/sovrascrittura dei salvataggi</translation>
    </message>
    <message>
        <source>Save the options for further uses</source>
        <translation>Salva le opzioni per ulteriori usi</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>Riguardo a...</translation>
    </message>
    <message>
        <source>PBP Files</source>
        <translation>Files PBP</translation>
    </message>
    <message>
        <source>open file dialog</source>
        <translation>Files PBP</translation>
    </message>
    <message>
        <source>Choose a PSP executable</source>
        <translation>Files PBP</translation>
    </message>
    <message>
        <source>Choose an icon file</source>
        <translation>Files PBP</translation>
    </message>
    <message>
        <source>Choose a background file</source>
        <translation>Scegli un file di sfondo</translation>
    </message>
    <message>
        <source>get existing directory</source>
        <translation>scegli un file di sfondo</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Scegli una cartella</translation>
    </message>
    <message>
        <source>Choose a PMF file</source>
        <translation>Scegli una cartella</translation>
    </message>
    <message>
        <source>Choose an AT3 file</source>
        <translation>Scegli una cartella</translation>
    </message>
    <message>
        <source>Your PSP is too fresh. There is no hack to put homebrew software on your device, yet.
Section PBP File was disabled!</source>
        <translation>La tua PSP ?troppo recente.Nessun hack permette di caricare homebrew sulla tua PSP, perlomeno non ancora...
La sezione PBP files ?disabilitata!</translation>
    </message>
    <message>
        <source>Choose the directory</source>
        <translation>Scegli la cartella</translation>
    </message>
    <message>
        <source>Some options are not correctly set</source>
        <translation>Scegli la cartella</translation>
    </message>
    <message>
        <source>You must open a PBP file before transfering files</source>
        <translation>Devi aprire un file PBP prima di trasferire files</translation>
    </message>
    <message>
        <source>You must set the PSP directory before transfering files</source>
        <translation>Devi aprire un file PBP prima di trasferire files</translation>
    </message>
    <message>
        <source>Files will be transferred to </source>
        <translation>Devi aprire un file PBP prima di trasferire files </translation>
    </message>
    <message>
        <source>The program name is not valid</source>
        <translation>Il nome del programma non ?corretto</translation>
    </message>
    <message>
        <source>Invalid background image. Check is 480x272 in size</source>
        <translation>Immagine di sfondo non valida.Controlla che la dimensione sia 480x272</translation>
    </message>
    <message>
        <source>Invalid PMF file</source>
        <translation>Immagine di sfondo non valida.Controlla che la dimensione sia 480x272</translation>
    </message>
    <message>
        <source>Invalid AT3 file</source>
        <translation>File AT3 non valido</translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>windowAbout</name>
    <message>
        <source>About/Help</source>
        <translation>Riguardo a/Aiuto</translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;html&gt;
&lt;head&gt;
<byte value="x9"/>&lt;meta HTTP-EQUIV=&quot;CONTENT-TYPE&quot; CONTENT=&quot;text/html; charset=utf-8&quot;&gt;
<byte value="x9"/>&lt;title&gt;QPSPManager: About&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1 align=center&gt;QPSPManager&lt;/h1&gt;&lt;p align=center&gt;
The Linux PSP File Manager&lt;/p&gt;
&lt;p align=center&gt;
version 1.2
&lt;/p&gt;
&lt;p align=center&gt;
(C) 2005 Bernat Ràfales Mulet
&lt;/p&gt;
&lt;p align=center&gt;
&lt;a href=&quot;http://qpspmanager.sourceforge.net&quot;&gt;http://qpspmanager.sourceforge.net&lt;/a&gt;
&lt;/p&gt;
&lt;h2&gt;Information&lt;/h2&gt;
&lt;p&gt;
QPSPManager is a PSP File manager for Linux. It&apos;s intended to use as a user friendly GUI to the known tedious pack and unpack processes of the PSP PBP files, directory generation and further copy into the PSP in order to execute those files in firmwares 1.50, providing some other features as selecting a custom icon or background file to show on the menu. It also provides support for backuping savegames on the computer.
&lt;/p&gt;
&lt;h2&gt;Authors&lt;/h2&gt;
&lt;p&gt;
This program was designed and developed by Bernat Ràfales Mulet.
&lt;h2&gt;Report bugs / Feedback / Contact author&lt;/h2&gt;
&lt;p&gt;
Please feel free to report bugs, feedbacks or suggestions to the author at &lt;a href=&quot;mailto:the_bell@users.sourceforge.net&quot;&gt;the_bell@users.sourceforge.net&lt;/a&gt;.
&lt;/p&gt;
&lt;p&gt;
Don&apos;t forget to visit the Official home page at &lt;a href=&quot;http://qpspmanager.sourceforge.net&quot;&gt;http://qpspmanager.sourceforge.net&lt;/a&gt; for updates or news about QPSPManager.
&lt;/p&gt;
&lt;h2&gt;Special thanks&lt;/h2&gt;
&lt;p&gt;
Special thanks go to Dan Peori (&lt;a href=&quot;mailto:peori@oopo.net&quot;&gt;peori@oopo.net&lt;/a&gt;) for writing the pack and unpack programs which helped me to understand the structure of the PBP file format.
&lt;/p&gt;
&lt;p&gt;
Special thanks to Sebastian Henschel and Philippe Maes for the distribution files and support.
&lt;/p&gt;
&lt;h2&gt;License&lt;/h2&gt;
&lt;p&gt;
This program is distributed under the terms of the GPL v2. Please read the LICENSE file included in the distribution of the program for more information.
&lt;/p&gt;
&lt;p&gt;
This program comes with NO WARRANTY and is distributed AS IS, use it at your own risk. The author takes no responsability of the possible damage caused to your computer or your PSP.
&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
