/***************************************************************************
 *   Copyright (C) 2005 by Bernat Ràfales                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

//$Revision: 1.2 $

//TODO: All :)

#ifndef SAVEGAMEMANAGER_H
#define SAVEGAMEMANAGER_H

#include <qstring.h>
#include <qobject.h>
#include <qstringlist.h>
#include "pspoptions.h"
#include <qdatetime.h>

/**
@author Bernat Ràfales
*/
class savegameManager
{

//TODO: file operations are copied from the PBPManager file. Maybe we should
//consider doing a filemanagement class with static functions
public:
    savegameManager(PSPOptions *options);
    ~savegameManager();
    QStringList getComputerSavegames();
    QStringList getPSPSavegames();
    bool existsComputer(QString directory);
    bool existsPSP(QString directory);
    QString getComputerOverwriteMessage(QString directory);
    QString getPSPOverwriteMessage(QString directory);
    bool transferSavegamePSP(QString directory);
    bool transferSavegameComputer(QString directory);
    QString getMessageErrorTransferring();
    QString getMessageErrorDeleting();
    bool deletePSPSavegame(QString directory);
    bool deleteComputerSavegame(QString directory);
    QString getDeleteSavegameMessage(QString directory);

private:
    PSPOptions *options;
    QStringList getSavegames(QString directory);
    void addSavegame(QFileInfo *info, QStringList *list);
    QString getName(QString file);
    bool existsSavegame(QString directory, QString savegame);
    QDateTime getDate(QString directory, QString savegame);
    bool transferSavegame(QString directory, QString savegame);
    bool deleteSavegame(QString directory);
};

#endif
