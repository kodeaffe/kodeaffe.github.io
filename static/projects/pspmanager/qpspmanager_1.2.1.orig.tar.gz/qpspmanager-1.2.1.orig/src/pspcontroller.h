/***************************************************************************
 *   Copyright (C) 2005 by Bernat Ràfales                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

//$Revision: 1.4 $

#ifndef PSPCONTROLLER_H
#define PSPCONTROLLER_H

#include <qobject.h>
#include "pbpmanager.h"
#include "mainwindow.h"
#include "pspoptions.h"
#include "savegamemanager.h"

/**
  @author Bernat Ràfales
  */

class PBPManager;

class PSPController
{

    public:
        PSPController(mainWindow *mainwindow);
        ~PSPController();
        void openPBPFile(QString filename);
        void openIcon(QString filename);
        void openPMF(QString filename);
        void openAT3(QString filename);
        void openBackground(QString filename);
        void openPSPDir(QString dir);
        void savePreferences();
        void setHideDamage(bool ok);
        void setProgramName(QString name);
        void setOutputPSPDir();
        void transferFiles();
        void iconEnabled(bool enabled);
        void backgroundEnabled(bool enabled);
        void PMFEnabled(bool enabled);
        void AT3Enabled(bool enabled);
        bool askOverwriteFiles();
        bool checkPSPDir();
        void transferSavegamesComputer(QStringList list);
        void transferSavegamesPSP(QStringList list);
        void setOverwriteSavegames(bool overwrite);
        void deleteComputerSavegames(QStringList savegames);
        void deletePSPSavegames(QStringList savegames);
        void hideDamage(QString directory);
    private:
        PBPManager *pbpmanager;
        mainWindow *mainwindow;
        savegameManager *savegamemanager;
        PSPOptions *options;
        short pspversion;
        void setSavegames();
        void findPSPVersion(PSPOptions *options);
};

#endif

