/***************************************************************************
 *   Copyright (C) 2005 by Bernat Ràfales                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

//$Revision: 1.5 $

#include "filemanager.h"


fileManager::fileManager()
{
}


fileManager::~fileManager()
{
}


bool fileManager::copyFiles(QDir outputDir, QFileInfoList dirList)
{
    QFileInfo *file;
    for (file = dirList.first(); file; file = dirList.next())
    {
        if (file->isDir())
        {
            //Create the dir and copy the files recursively
            QDir newOutDir((outputDir.absPath() + "/" + file->fileName()));
            if (!newOutDir.mkdir(newOutDir.absPath()))
            {
                return FALSE;
            }
            QDir subdir(file->absFilePath());
            QFileInfoList subdirList(*(subdir.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoSymLinks)));
            subdirList.removeFirst();
            subdirList.removeFirst();
            if (!copyFiles(newOutDir, subdirList))
            {
                deleteDir(newOutDir.absPath());
                return FALSE;
            }
        }
        else
        {
            //Copy the file (assumes output path is already created)
            if (!copyFile(file->absFilePath(), outputDir.absPath() + "/" + file->fileName()))
            {
                return FALSE;
            }
        }
    }
    return TRUE;
}


bool fileManager::copyFile(QString inputFile, QString outputFile)
{
    QFile inFile(inputFile);
    QFile outFile(outputFile);
    if ((!inFile.open(IO_ReadOnly)) || (!outFile.open(IO_WriteOnly)))
    {
        return FALSE;
    }
    QDataStream inStream(&inFile);
    QDataStream outStream(&outFile);
    char *fileData = (char *)malloc(inFile.size());
    if (fileData == 0) //malloc problem
    {
        outFile.remove();
        inFile.close();
        return FALSE; 
    }
    inStream.readRawBytes(fileData, inFile.size());
    outStream.writeRawBytes(fileData, inFile.size());
    inFile.close();
    outFile.close();
    delete(fileData);
    return TRUE;
}


//Deletes de directory recursively. Returns FALSE if any file
//or dir fails to be removed
bool fileManager::deleteDir(QString directory)
{
    QDir dir(directory);
    if (!dir.exists(directory))
    {
        return TRUE;
    }
    QFileInfoList dirList(*(dir.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoSymLinks)));
    //Remove . and .. dirs
    dirList.removeFirst();
    dirList.removeFirst();
    for (QFileInfo *file = dirList.first(); file; file = dirList.next())
    {
        if (file->isDir())
        {
            if (deleteDir(file->absFilePath()))
            {
                if (!dir.rmdir(file->absFilePath()))
                {
                    return FALSE;
                }
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            QFile fileToRemove(file->absFilePath());
            if (!fileToRemove.remove())
            {
                return FALSE;
            }
        }
    }
    return dir.rmdir(directory);
}


//Copies a source folder to a destination folder
bool fileManager::copyFolder(QDir source, QDir dest)
{
    if (!dest.exists(dest.absPath()))
    {
        dest.mkdir(dest.absPath());
    }

    QFileInfoList dirList(*(source.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoSymLinks)));
    dirList.removeFirst();
    dirList.removeFirst();
    if (copyFiles(dest, dirList))
    {
        return TRUE;
    }
    else
    {
        dest.rmdir(dest.absPath());
        return FALSE;
    }
}